package com.farmerproject.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.farmerproject.demo.repository.ClaimIMPL;

@SpringBootApplication
public class FarmerBidderProjectFinalApplication {
	static Logger logger = LoggerFactory.getLogger(FarmerBidderProjectFinalApplication.class);
    
	public static void main(String[] args) {
		logger.info("Main Application started........");
		SpringApplication.run(FarmerBidderProjectFinalApplication.class, args);
		logger.info("Project sucessfully started");
	}

}
