package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.farmerproject.demo.entity.Bidder;
import com.farmerproject.demo.service.ServiceBidderImpl;



@RestController
@RequestMapping("/bidder")
@CrossOrigin(origins = "*")
public class ControllerBidder {
//http://localhost:8080/bidder/get/36
	//Logger logger = LoggerFactory.getLogger(LoggingController.class);
	//logger.info("Bidder Controller......")
	@Autowired
	ServiceBidderImpl serviceBidderImpl;

	@PostMapping("/add")
	public void insertBidder(@RequestBody Bidder bidder) {
		serviceBidderImpl.insertBidder(bidder);

	}
     @PutMapping("/update/{b_bid}")
	public void updateBidder(@RequestBody Bidder bidder) {
    	 serviceBidderImpl.updateBidder(bidder);
	}
     
     @DeleteMapping("/delete/{b_bid}")
     public void deleteBidder(@PathVariable("b_bid")int x) {
    	 serviceBidderImpl.removeBidder(x) ;
     }
     
     @GetMapping("/get/{x}")
     public Bidder selectBidder( @PathVariable int x) {
    	return serviceBidderImpl.selectBidder(x);
     }
     
     @GetMapping("/getAll")
     public List<Bidder> selectAllBidder() {
    	return serviceBidderImpl.selectAllBidder();
     }
}
