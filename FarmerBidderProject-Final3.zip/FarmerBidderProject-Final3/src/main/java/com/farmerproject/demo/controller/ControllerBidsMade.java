package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.farmerproject.demo.entity.Bids_Made;
import com.farmerproject.demo.service.ServiceBidsMadeRepoImpl;


@RestController
@RequestMapping("/bidsmade")
@CrossOrigin(origins = "*")
public class ControllerBidsMade {
	@Autowired
	ServiceBidsMadeRepoImpl serviceBidsMadeRepoImpl;
	
	@PostMapping("/add")
	public void insertBidsMade( @RequestBody Bids_Made Bids_Made) {
		serviceBidsMadeRepoImpl.insertBidsMade(Bids_Made);
	}
	
	@PutMapping("/update")
	public void updateBidsMade(@RequestBody Bids_Made bidMade) {
		serviceBidsMadeRepoImpl.updateBidsMade(bidMade);
	}
	
	@DeleteMapping("/delete/{x}")
	public void deleteBidsMade(@PathVariable int x) {
		serviceBidsMadeRepoImpl.deleteBidsMade(x);
	}
	
	@GetMapping("/get/{x}")
	public Bids_Made selectBidsMade(@PathVariable int x) {
		return serviceBidsMadeRepoImpl.selectBidsMade(x);
	}
	
	@GetMapping("/getAll")
	public List<Bids_Made> selectAllBidsMade() {
		// TODO Auto-generated method stub
		return serviceBidsMadeRepoImpl.selectAllBidsMade();
	}
	
	
	@GetMapping("/getAll1")
	public String selectAllBidsMade1() {
		// TODO Auto-generated method stub
		return "Shubham";
	}



}
