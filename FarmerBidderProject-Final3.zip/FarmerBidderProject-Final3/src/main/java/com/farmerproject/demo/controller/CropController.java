package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.farmerproject.demo.entity.Crop;

import com.farmerproject.demo.service.CropServiceImpl;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/crop")
public class CropController {

	@Autowired
	private CropServiceImpl cropService;

	@GetMapping("/list")
	public List<Crop> getAllCropList() {	
		List<Crop> croplist;
		croplist=cropService.getCropDetails();
		return croplist;

	}

	@PostMapping(value = "/add")
	public void insertCrop(@RequestBody Crop cropObj) {
		cropService.insertCrop(cropObj);
	}

	@PutMapping(value = "/update")
	public void updateCropDetails(@RequestBody Crop cropObj) {
		cropService.updateCropDetails(cropObj);
	}

	@DeleteMapping(value = "/delete/{cropid}")
	public void deleteCropDetails(@PathVariable int cropid) {
		cropService.deleteCropDetails(cropid);
	}

	@GetMapping("get/{cropid}")
	public Crop fetchCropByCrop(@PathVariable int cropid) {
		return cropService.fetchById(cropid);

	}

}
