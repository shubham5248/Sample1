package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.farmerproject.demo.entity.Farmer;
import com.farmerproject.demo.service.FarmerServiceIMPL;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/farmer")
public class FarmerController {

	@Autowired
	FarmerServiceIMPL farmerService;

	@GetMapping("/list")
	public List<Farmer> getFarmerDetails() {
		List<Farmer> farmList;
		farmList = farmerService.getFarmerDetails();
		return farmList;

	}

	@PostMapping(value = "/add")
	public void insertFarmerDetails(@RequestBody Farmer farmerObj) {
		farmerService.insertFarmerDetails(farmerObj);

	}

	@PutMapping(value = "/update")
	public void updateFarmerDetails(@RequestBody Farmer farmerObj) {
		farmerService.updateFarmerDetails(farmerObj);
	}

	@DeleteMapping(value = "/delete/{farmerId}")
	public void deleteFarmerDetails(@PathVariable int farmerId) {
		farmerService.deleteFarmerDetails(farmerId);
	}

	@GetMapping("/get/{farmerId}")
	public Farmer fetchFarmerDetailsById(@PathVariable int farmerId) {
		return farmerService.fetchFarmerDetailsById(farmerId);
	}

}
