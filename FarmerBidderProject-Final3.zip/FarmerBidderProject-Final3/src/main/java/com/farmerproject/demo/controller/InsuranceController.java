package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.farmerproject.demo.entity.Insurance;
import com.farmerproject.demo.service.InsuranceServiceIMPL;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/insurance")
public class InsuranceController {

	@Autowired
	private InsuranceServiceIMPL insuranceService;

	@GetMapping("/list")
	public List<Insurance> getALlInsuranceDetails() {
		return insuranceService.getInsuranceDetails();

	}

	@PostMapping(value = "/add")
	public void insertInsuranceDetails(@RequestBody Insurance insuranceObj) {
		insuranceService.insertInsuranceDetails(insuranceObj);

	}

	@PutMapping(value = "/update/")
	public void updateInstituteDetails(@RequestBody Insurance insuranceObj) {
		insuranceService.updateInsuranceDetails(insuranceObj);
	}

	@DeleteMapping(value = "/delete/{policyNumber}")
	public void deleteInsuranceDetailRecord(@PathVariable int policyNumber) {

		insuranceService.deleteInsuranceDetails(policyNumber);
	}

	@GetMapping("/get/{policyNumber}")
	public Insurance fetchInsuranceDetailsById(@PathVariable int policyNumber) {
		return insuranceService.fetchInsuranceDetailsBypolicyNumber(policyNumber);
	}

}
