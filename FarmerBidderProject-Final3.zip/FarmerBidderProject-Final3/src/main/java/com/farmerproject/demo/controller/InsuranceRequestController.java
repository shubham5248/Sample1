package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.farmerproject.demo.entity.InsuranceRequest;
import com.farmerproject.demo.service.InsuranceRequestServiceIMPL;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/insuranceRequest")
public class InsuranceRequestController {

	@Autowired
	InsuranceRequestServiceIMPL insuranceReqService;

	@GetMapping("/list")
	public List<InsuranceRequest> getInsuranceRequestDetails() {
		return insuranceReqService.getInsuranceRequestDetails();

	}

	@PostMapping("/add")
	public void insertInsuranceRequestDetails(@RequestBody InsuranceRequest insuranceReqObj) {
		insuranceReqService.insertInsuranceRequestDetails(insuranceReqObj);
	}

	@PutMapping("/update")
	public void updateInsuranceRequestDetails(@RequestBody InsuranceRequest insuranceReqObj) {
		insuranceReqService.updateInsuranceRequestDetails(insuranceReqObj);
	}

	@DeleteMapping("/delete/{insReqNo}")
	public void deleteInsuranceRequestDetails(@PathVariable int insReqNo) {
		insuranceReqService.deleteInsuranceRequestDetails(insReqNo);
	}

	@GetMapping("get/{insReqNo}")
	public InsuranceRequest fetchInsuranceRequestDetailsByrequestno(@PathVariable int insReqNo) {
		return insuranceReqService.fetchInsuranceRequestDetailsByrequestno(insReqNo);
	}

}
