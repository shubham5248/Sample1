package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.farmerproject.demo.entity.PolicyDetails;
import com.farmerproject.demo.service.PolicyServiceIMPL;

@RestController
@RequestMapping("/policyDetails")
public class PolicyDetailsController {

	@Autowired
	private PolicyServiceIMPL policyService;

	@GetMapping("/list")
	public List<PolicyDetails> getPolicyDetails() {
		return policyService.getPolicyDetails();

	}

	@PostMapping(value = "/add")
	public void insertPolicyDetails(@PathVariable PolicyDetails policyDetailsObj) {
		policyService.insertPolicyDetails(policyDetailsObj);
	}

	@PutMapping(value = "/update")
	public void updateInstituteDetails(@RequestBody PolicyDetails policyDetailsObj) {
		policyService.updatePolicyDetails(policyDetailsObj);
	}

	@DeleteMapping(value = "/delete/{policyNumber}")
	public void deletePolicyDetails(@PathVariable int policyNumber) {
		policyService.deletePolicyDetails(policyNumber);
	}

	@GetMapping("get/{policyNumber}")
	public PolicyDetails fetchPolicyDetailsByPolicyNumber(@PathVariable int policyNumber) {
		return policyService.fetchPolicyDetailsByPolicyNumber(policyNumber);
	}

}
