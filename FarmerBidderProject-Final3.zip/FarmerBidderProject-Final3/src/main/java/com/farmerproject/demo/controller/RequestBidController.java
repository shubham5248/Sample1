package com.farmerproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.farmerproject.demo.entity.RequestBid;
import com.farmerproject.demo.service.RequestBidServiceIMPL;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/req")
public class RequestBidController {

	@Autowired
	private RequestBidServiceIMPL requestBidService;


	@GetMapping("/list")
	public List<RequestBid> getRequestBidDetails() {
		List<RequestBid> reqBidList;
		reqBidList = requestBidService.getRequestBidDetails();
		return reqBidList;

	}

	@PostMapping("/add")
	public void insertRequestBidDetails(@RequestBody RequestBid requestBidObj) {
		requestBidService.insertRequestBidDetails(requestBidObj);
	}

	@PutMapping("/update")
	public void updateInstituteDetails(@RequestBody RequestBid requestBidObj) {
		requestBidService.updateRequestBidDetails(requestBidObj);
	}

	@DeleteMapping("/delete/{requestNo}")
	public void deleteRequestBidDetails(@PathVariable int requestNo) {
		requestBidService.deleteRequestBidDetails(requestNo);
	}

	@GetMapping("/get/{requestNo}")
	public RequestBid fetchRequestBidDetailsById(@PathVariable int requestNo) {
		return requestBidService.fetchRequestBidDetailsById(requestNo);
	}

}
