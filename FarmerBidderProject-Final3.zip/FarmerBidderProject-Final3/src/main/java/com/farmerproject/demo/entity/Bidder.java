package com.farmerproject.demo.entity;






import java.util.HashSet;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name= "bidder01")
public class Bidder {
	@Id
	@GeneratedValue
	@Column(name = "B_Id")
	private int b_bid;
//	
	
//private Set<Bids_Made> bids_made=new HashSet<Bids_Made>();
	
	

	private String b_name;
	
	private String b_email;
	
	private long b_contact_no;
	
	private String b_address;
	
	private String b_trader_license;
	
	private long b_pincode;
	
	private String b_city;
	
	private String b_state;
	
	private long b_adharcard;
	
	private long b_account_number;
	
	private String b_ifsc;
	
	private String b_bank_name;

	@OneToMany(cascade = CascadeType.ALL, mappedBy="bidder" ,fetch = FetchType.EAGER)
    private  Set <Bids_Made> bids_made= new HashSet<Bids_Made>();

	@OneToMany(cascade = CascadeType.ALL, mappedBy="bidder" ,fetch = FetchType.EAGER)
    private  Set <SoldHistory> soldHistories= new HashSet<SoldHistory>();

	public Set<SoldHistory> getSoldHistories() {
		return soldHistories;
	}

	public void setSoldHistories(Set<SoldHistory> soldHistories) {
		this.soldHistories = soldHistories;
	}

	public Set<Bids_Made> getBids_made() {
		return bids_made;
	}

	public void setBids_made(Set<Bids_Made> bids_made) {
		this.bids_made = bids_made;
	}

	public int getB_bid() {
		return b_bid;
	}

	public void setB_bid(int b_bid) {
		this.b_bid = b_bid;
	}

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}

	public String getB_email() {
		return b_email;
	}

	public void setB_email(String b_email) {
		this.b_email = b_email;
	}

	public long getB_contact_no() {
		return b_contact_no;
	}

	public void setB_contact_no(long b_contact_no) {
		this.b_contact_no = b_contact_no;
	}

	public String getB_address() {
		return b_address;
	}

	public void setB_address(String b_address) {
		this.b_address = b_address;
	}

	public String getB_trader_license() {
		return b_trader_license;
	}

	public void setB_trader_license(String b_trader_license) {
		this.b_trader_license = b_trader_license;
	}

	public long getB_pincode() {
		return b_pincode;
	}

	public void setB_pincode(long b_pincode) {
		this.b_pincode = b_pincode;
	}

	public String getB_city() {
		return b_city;
	}

	public void setB_city(String b_city) {
		this.b_city = b_city;
	}

	public String getB_state() {
		return b_state;
	}

	public void setB_state(String b_state) {
		this.b_state = b_state;
	}

	public long getB_adharcard() {
		return b_adharcard;
	}

	public void setB_adharcard(long b_adharcard) {
		this.b_adharcard = b_adharcard;
	}

	public long getB_account_number() {
		return b_account_number;
	}

	public void setB_account_number(long b_account_number) {
		this.b_account_number = b_account_number;
	}

	public String getB_ifsc() {
		return b_ifsc;
	}

	public void setB_ifsc(String b_ifsc) {
		this.b_ifsc = b_ifsc;
	}

	public String getB_bank_name() {
		return b_bank_name;
	}

	public void setB_bank_name(String b_bank_name) {
		this.b_bank_name = b_bank_name;
	}
	
	
	
	
	
	
	

}
