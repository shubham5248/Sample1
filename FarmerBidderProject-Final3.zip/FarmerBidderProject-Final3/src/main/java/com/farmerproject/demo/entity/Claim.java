package com.farmerproject.demo.entity;



import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "claim10")
public class Claim {

	@Id
	@GeneratedValue
	private int policyNum;
	private String reason;
	private LocalDate dateOfClaim;

	@OneToOne
	PolicyDetails policyDetailsObj;

	public PolicyDetails getPolicyDetailsObj() {
		return policyDetailsObj;
	}

	public void setPolicyDetailsObj(PolicyDetails policyDetailsObj) {
		this.policyDetailsObj = policyDetailsObj;
	}

	public int getPolicyNum() {
		return policyNum;
	}

	public void setPolicyNum(int policyNum) {
		this.policyNum = policyNum;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public LocalDate getDateOfClaim() {
		return dateOfClaim;
	}

	public void setDateOfClaim(LocalDate dateOfClaim) {
		this.dateOfClaim = dateOfClaim;
	}

}