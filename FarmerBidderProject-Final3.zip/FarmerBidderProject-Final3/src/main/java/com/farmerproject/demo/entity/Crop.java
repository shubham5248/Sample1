package com.farmerproject.demo.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="crop01")
public class Crop {
	
	@Id
	@GeneratedValue
	private int cropId; 
	
	private String cropType;
	private double cropPremium;
	private double cropMsp;
	private double cropBasePrice;
	private double currentPrice;
	
	

	@ManyToOne
	@JoinColumn(name="farmerId")
	private Farmer farmerObj2;
	

	public Farmer getFarmerObj2() {
		return farmerObj2;
	}
	public void setFarmerObj2(Farmer farmerObj2) {
		this.farmerObj2 = farmerObj2;
	}
	@OneToOne
	private RequestBid reqObj;
	
	
	
	public RequestBid getReqObj() {
		return reqObj;
	}
	public void setReqObj(RequestBid reqObj) {
		this.reqObj = reqObj;
	}
	public int getCropId() {
		return cropId;
	}
	public void setCropId(int cropId) {
		this.cropId = cropId;
	}
	public String getCropType() {
		return cropType;
	}
	public void setCropType(String cropType) {
		this.cropType = cropType;
	}
	public double getCropPremium() {
		return cropPremium;
	}
	public void setCropPremium(double cropPremium) {
		this.cropPremium = cropPremium;
	}
	public double getCropMsp() {
		return cropMsp;
	}
	public void setCropMsp(double cropMsp) {
		this.cropMsp = cropMsp;
	}
	public double getCropBasePrice() {
		return cropBasePrice;
	}
	public void setCropBasePrice(double cropBasePrice) {
		this.cropBasePrice = cropBasePrice;
	}
	public double getCurrentPrice() {
		return currentPrice;
	}
	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}
	
	

}
