package com.farmerproject.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "farmer11")
public class Farmer {

	@Id
	@GeneratedValue
	@Column(name = "farmerId")
	private int farmerId;

	private String farmerName;

	private String farmerEmail;

	private long farmerContact;

	private String farmerHomeAddress;

	private int farmerPinCode;

	private String farmerCity;

	private String farmerState;

	private long farmerAadharCard;

	private String farmerArea;

	private String farmerLandAddress;

	private long farmerLandPinCode;

	private String farmerLandCity;

	private String farmerLandState;

	private long farmerAccountNumber;

	private long farmerBanfIFSCcode;

	private String farmerBank;


	@OneToMany(mappedBy = "farmerObj2", cascade = CascadeType.ALL)
	private Set<Crop> cropObj = new HashSet<Crop>();
	
	
	
	@OneToMany(mappedBy = "farmerObj", cascade = CascadeType.ALL)
	private Set<Insurance> insuranceObj = new HashSet<Insurance>();
	
	@OneToMany(mappedBy = "farmerObj3",cascade = CascadeType.ALL)
	private Set<RequestBid> requestBidObj=new HashSet<RequestBid>();
	
	
	

	public Set<Insurance> getInsuranceObj() {
		return insuranceObj;
	}

	public void setInsuranceObj(Set<Insurance> insuranceObj) {
		this.insuranceObj = insuranceObj;
	}

	public int getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}

	public String getFarmerName() {
		return farmerName;
	}

	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}

	public String getFarmerEmail() {
		return farmerEmail;
	}

	public void setFarmerEmail(String farmerEmail) {
		this.farmerEmail = farmerEmail;
	}

	public long getFarmerContact() {
		return farmerContact;
	}

	public void setFarmerContact(long farmerContact) {
		this.farmerContact = farmerContact;
	}

	public String getFarmerHomeAddress() {
		return farmerHomeAddress;
	}

	public void setFarmerHomeAddress(String farmerHomeAddress) {
		this.farmerHomeAddress = farmerHomeAddress;
	}

	public int getFarmerPinCode() {
		return farmerPinCode;
	}

	public void setFarmerPinCode(int farmerPinCode) {
		this.farmerPinCode = farmerPinCode;
	}

	public String getFarmerCity() {
		return farmerCity;
	}

	public void setFarmerCity(String farmerCity) {
		this.farmerCity = farmerCity;
	}

	public String getFarmerState() {
		return farmerState;
	}

	public void setFarmerState(String farmerState) {
		this.farmerState = farmerState;
	}

	public long getFarmerAadharCard() {
		return farmerAadharCard;
	}

	public void setFarmerAadharCard(long farmerAadharCard) {
		this.farmerAadharCard = farmerAadharCard;
	}

	public String getFarmerArea() {
		return farmerArea;
	}

	public void setFarmerArea(String farmerArea) {
		this.farmerArea = farmerArea;
	}

	public String getFarmerLandAddress() {
		return farmerLandAddress;
	}

	public void setFarmerLandAddress(String farmerLandAddress) {
		this.farmerLandAddress = farmerLandAddress;
	}

	public long getFarmerLandPinCode() {
		return farmerLandPinCode;
	}

	public void setFarmerLandPinCode(long farmerLandPinCode) {
		this.farmerLandPinCode = farmerLandPinCode;
	}

	public String getFarmerLandCity() {
		return farmerLandCity;
	}

	public void setFarmerLandCity(String farmerLandCity) {
		this.farmerLandCity = farmerLandCity;
	}

	public String getFarmerLandState() {
		return farmerLandState;
	}

	public void setFarmerLandState(String farmerLandState) {
		this.farmerLandState = farmerLandState;
	}

	public long getFarmerAccountNumber() {
		return farmerAccountNumber;
	}

	public void setFarmerAccountNumber(long farmerAccountNumber) {
		this.farmerAccountNumber = farmerAccountNumber;
	}

	public long getFarmerBanfIFSCcode() {
		return farmerBanfIFSCcode;
	}

	public void setFarmerBanfIFSCcode(long farmerBanfIFSCcode) {
		this.farmerBanfIFSCcode = farmerBanfIFSCcode;
	}

	public String getFarmerBank() {
		return farmerBank;
	}

	public void setFarmerBank(String farmerBank) {
		this.farmerBank = farmerBank;
	}

}