package com.farmerproject.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Insurance02")
public class Insurance {

	@Id
	@GeneratedValue
	private int policyNumber;

	@ManyToOne
	@JoinColumn(name = "farmerId")
	private Farmer farmerObj;

	@OneToOne
	private InsuranceRequest insuranceRequestObject;

	public Farmer getFarmerObj() {
		return farmerObj;
	}

	public void setFarmerObj(Farmer farmerObj) {
		this.farmerObj = farmerObj;
	}

	public InsuranceRequest getInsuranceRequestObject() {
		return insuranceRequestObject;
	}

	public void setInsuranceRequestObject(InsuranceRequest insuranceRequestObject) {
		this.insuranceRequestObject = insuranceRequestObject;
	}

	public int getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

}