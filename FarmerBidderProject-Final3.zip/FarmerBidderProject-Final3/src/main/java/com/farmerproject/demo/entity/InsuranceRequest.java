package com.farmerproject.demo.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "insurance11")
public class InsuranceRequest {

	@Id
	@GeneratedValue
	private int pdRequestNo;

	@Column(name = "iFid")
	private int iFid;

	@Column(name = "iseason")
	private String iseason;

	@Column(name = "ild")
	private LocalDate ild;

	@Column(name = "iCrop")
	private String iCrop;

	@Column(name = "iSumInsured")
	private Float iSumInsured;

	@Column(name = "iCompany")
	private String iCompany;

	@Column(name = "iNomineeName")
	private String iNomineeName;

	@Column(name = "iLandArea")
	private String iLandArea;

	@Column(name = "iPreAmount")
	private Float iPreAmount;

	@OneToOne
	@JoinColumn(name = "PO_Id")
//	@PrimaryKeyJoinColumn
	private PolicyDetails policyDetailsObj;

	@OneToOne
	private Insurance insuranceObj;

	public Insurance getInsuranceObj() {
		return insuranceObj;
	}

	public void setInsuranceObj(Insurance insuranceObj) {
		this.insuranceObj = insuranceObj;
	}

	public PolicyDetails getPolicyDetailsObj() {
		return policyDetailsObj;
	}

	public void setPolicyDetailsObj(PolicyDetails policyDetailsObj) {
		this.policyDetailsObj = policyDetailsObj;
	}

	public int getPdRequestNo() {
		return pdRequestNo;
	}

	public void setPdRequestNo(int pdRequestNo) {
		this.pdRequestNo = pdRequestNo;
	}

	public int getiFid() {
		return iFid;
	}

	public void setiFid(int iFid) {
		this.iFid = iFid;
	}

	public String getIseason() {
		return iseason;
	}

	public void setIseason(String iseason) {
		this.iseason = iseason;
	}

	public LocalDate getIld() {
		return ild;
	}

	public void setIld(LocalDate ild) {
		this.ild = ild;
	}

	public String getiCrop() {
		return iCrop;
	}

	public void setiCrop(String iCrop) {
		this.iCrop = iCrop;
	}

	public Float getiSumInsured() {
		return iSumInsured;
	}

	public void setiSumInsured(Float iSumInsured) {
		this.iSumInsured = iSumInsured;
	}

	public String getiCompany() {
		return iCompany;
	}

	public void setiCompany(String iCompany) {
		this.iCompany = iCompany;
	}

	public String getiNomineeName() {
		return iNomineeName;
	}

	public void setiNomineeName(String iNomineeName) {
		this.iNomineeName = iNomineeName;
	}

	public String getiLandArea() {
		return iLandArea;
	}

	public void setiLandArea(String iLandArea) {
		this.iLandArea = iLandArea;
	}

	public Float getiPreAmount() {
		return iPreAmount;
	}

	public void setiPreAmount(Float iPreAmount) {
		this.iPreAmount = iPreAmount;
	}

}