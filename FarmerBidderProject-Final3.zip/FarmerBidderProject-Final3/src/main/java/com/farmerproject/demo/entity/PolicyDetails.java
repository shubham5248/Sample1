package com.farmerproject.demo.entity;



import java.time.LocalDate;


import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "policy10")
public class PolicyDetails {
	

	@Id
	@GeneratedValue
	@Column(name = "PO_Id")
	private int pdPolicyNum;

	private int pdRequestNo;

	private String pdCompany;

	private Float pdSum;

	private LocalDate pdld;
	
	@OneToOne
	private InsuranceRequest insReqPojo;

	public InsuranceRequest getInsReqPojo() {
		return insReqPojo;
	}

	public void setInsReqPojo(InsuranceRequest insReqPojo) {
		this.insReqPojo = insReqPojo;
	}
	@OneToOne
	private Claim claimObj;

	public Claim getClaimObj() {
		return claimObj;
	}

	public void setClaimObj(Claim claimObj) {
		this.claimObj = claimObj;
	}

	public int getPdPolicyNum() {
		return pdPolicyNum;
	}

	public void setPdPolicyNum(int pdPolicyNum) {
		this.pdPolicyNum = pdPolicyNum;
	}

	public String getPdCompany() {
		return pdCompany;
	}

	public void setPdCompany(String pdCompany) {
		this.pdCompany = pdCompany;
	}

	public Float getPdSum() {
		return pdSum;
	}

	public void setPdSum(Float pdSum) {
		this.pdSum = pdSum;
	}

	public LocalDate getPdld() {
		return pdld;
	}

	public void setPdld(LocalDate pdld) {
		this.pdld = pdld;
	}

	public int getPdRequestNo() {
		return pdRequestNo;
	}

	public void setPdRequestNo(int pdRequestNo) {
		this.pdRequestNo = pdRequestNo;
	}

}