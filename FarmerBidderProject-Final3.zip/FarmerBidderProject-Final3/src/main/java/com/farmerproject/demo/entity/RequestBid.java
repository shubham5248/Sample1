package com.farmerproject.demo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="requestbid01")
public class RequestBid {
	
	@Id
	@GeneratedValue
	private int bidRequestNo;
	
	private String cropName;
	private double quantityOfCrop;
	private double phOfSoil;
	private String fertilizerType;
	
	@OneToOne(cascade = CascadeType.ALL,mappedBy = "reqObj")
	private Crop cropObj;
	
	@ManyToOne
	@JoinColumn(name="farmerId")
	private Farmer farmerObj3;
	
	public Farmer getFarmerObj3() {
		return farmerObj3;
	}
	public void setFarmerObj3(Farmer farmerObj3) {
		this.farmerObj3 = farmerObj3;
	}
	public Crop getCropObj() {
		return cropObj;
	}
	public void setCropObj(Crop cropObj) {
		this.cropObj = cropObj;
	}
	public int getBidRequestNo() {
		return bidRequestNo;
	}
	public void setBidRequestNo(int bidRequestNo) {
		this.bidRequestNo = bidRequestNo;
	}
	public String getCropName() {
		return cropName;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public double getQuantityOfCrop() {
		return quantityOfCrop;
	}
	public void setQuantityOfCrop(double quantityOfCrop) {
		this.quantityOfCrop = quantityOfCrop;
	}
	public double getPhOfSoil() {
		return phOfSoil;
	}
	public void setPhOfSoil(double phOfSoil) {
		this.phOfSoil = phOfSoil;
	}
	public String getFertilizerType() {
		return fertilizerType;
	}
	public void setFertilizerType(String fertilizerType) {
		this.fertilizerType = fertilizerType;
	}
	
	

}
