package com.farmerproject.demo.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="Sold_History")
public class SoldHistory {
	@Id
	@Column(name="SrNo")
	@GeneratedValue
	private int srNo;
	
	
	@Column(name="Date")
	private LocalDate s_date;
	
	@Column(name="CropName")
	private String s_cropName;
	
	@Column(name="QTY")
	private String s_qty;
	
	@Column(name="MSP")
	private String s_msp;
	
	@Column(name="SoldPrice")
	private int s_soldPrice;
	
	@Column(name="TotalPrice")
	private int s_totalPrice;
	
	
	@ManyToOne
	private Bidder bidder;
	

	public Bidder getBidder() {
		return bidder;
	}

	public void setBidder(Bidder bidder) {
		this.bidder = bidder;
	}

	public int getSrNo() {
		return srNo;
	}

	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}

	public LocalDate getS_date() {
		return s_date;
	}

	public void setS_date(LocalDate s_date) {
		this.s_date = s_date;
	}

	public String getS_cropName() {
		return s_cropName;
	}

	public void setS_cropName(String s_cropName) {
		this.s_cropName = s_cropName;
	}

	public String getS_qty() {
		return s_qty;
	}

	public void setS_qty(String s_qty) {
		this.s_qty = s_qty;
	}

	public String getS_msp() {
		return s_msp;
	}

	public void setS_msp(String s_msp) {
		this.s_msp = s_msp;
	}

	public int getS_soldPrice() {
		return s_soldPrice;
	}

	public void setS_soldPrice(int s_soldPrice) {
		this.s_soldPrice = s_soldPrice;
	}

	public int getS_totalPrice() {
		return s_totalPrice;
	}

	public void setS_totalPrice(int s_totalPrice) {
		this.s_totalPrice = s_totalPrice;
	}




	
	

}
