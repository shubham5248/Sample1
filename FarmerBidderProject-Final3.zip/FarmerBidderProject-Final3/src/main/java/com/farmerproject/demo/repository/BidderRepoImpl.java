package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Bidder;

@Repository
public class BidderRepoImpl extends BaseRepository implements Bidderrepo {
	
	@Transactional
	public void insertBidder(Bidder bobj) {
		super.persist(bobj);
		
	}

	@Transactional
	public void updateBidder(Bidder bobj) {
		// TODO Auto-generated method stub
		super.merge(bobj);
	}

	
	public Bidder selectBidder(int b_bid) {
		// TODO Auto-generated method stub
	Bidder bid =super.find(Bidder.class, b_bid);
	return bid;
	
	}

	@Override
	public List<Bidder> selectAllBidder() {
		// TODO Auto-generated method stub
		return findAll("Bidder");

	}

	@Transactional
	public void removeBidder(int b_bid) {
		// TODO Auto-generated method stub
		super.remove(Bidder.class, b_bid);
		
	}

}
