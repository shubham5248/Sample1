package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.Bidder;

@Repository
interface Bidderrepo {
	
	void insertBidder(Bidder bobj);
	
	void updateBidder (Bidder bobj);
	
	Bidder selectBidder(int b_bid);
	
	List<Bidder> selectAllBidder();
	
	void removeBidder(int b_bid);

}
