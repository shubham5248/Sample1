package com.farmerproject.demo.repository;

import java.util.List;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Bids_Made;

@Repository
public class Bids_MadeRepoImpl extends BaseRepository implements Bids_MadeRepo {

	@Transactional
	public void bidsMadeInsert(Bids_Made bmObj) {
		super.persist(bmObj);
		
	}

	
	public Bids_Made selectBids_Made(int b_bidding_id) {
	
		return super.find(Bids_Made.class,  b_bidding_id);
	}


	public List<Bids_Made> selectAllBids_Made() {
	
		return super.findAll("Bids_Made");
	}

	@Transactional
	public void updateb_bidding_id(Bids_Made bmObj) {
		
		super.merge(bmObj);
	}

	@Transactional
	public void deleteb_bidding_id(int b_bidding_id) {
		
		super.remove(Bids_Made.class, b_bidding_id);
	}

}
