package com.farmerproject.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Claim;

@Repository
public class ClaimIMPL extends BaseRepository implements ClaimRepo {

	Logger logger = LoggerFactory.getLogger(ClaimIMPL.class);

	public ClaimIMPL() {
		System.out.println("ClaimIMPL()...ctor ");
	}

	@Transactional
	public void insertClaimDetails(Claim policyClaimObj1) {
		super.persist(policyClaimObj1); // invoking the dummy persist of the super class
		System.out.println("ClaimDetails inserted...");
		logger.info("ClaimDetails inserted...");

	}

	@Override
	public Claim fetchClaimDetailsById(int policyClaimNo) {

		logger.info("ClaimIMPL : selecting ClaimDetail by ClaimNo");
		Claim claimPolicyObj = super.find(Claim.class, policyClaimNo);
		if (claimPolicyObj == null) {
			logger.info("policy");
		}
		return claimPolicyObj;
	}

	@Override
	public List<Claim> selectClaimDetails() {
		List<Claim> insReqObj2 = new ArrayList<Claim>();

		logger.info("ClaimIMPL : Selecting all ClaimDetail...");
		
		return super.findAll("Claim");
	}

	@Transactional
	public void updateClaimDetail(Claim policyClaimObj2) {
		logger.info("ClaimIMPL : Updating ClaimDetail ...");

		super.merge(policyClaimObj2);

	}

	@Transactional
	public void deleteClaimDetail(int policyClaimNo) {
		logger.info("ClaimIMPL : Deleting ClaimDetail");

		super.remove(Claim.class, policyClaimNo);
	}

}
