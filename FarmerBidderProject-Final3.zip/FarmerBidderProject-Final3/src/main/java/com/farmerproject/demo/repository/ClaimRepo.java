package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.Claim;



@Repository
public interface ClaimRepo {
	void insertClaimDetails(Claim policyClaimObj1);

	Claim fetchClaimDetailsById(int policyClaimNo);

	List<Claim> selectClaimDetails();

	void updateClaimDetail(Claim policyClaimObj2);

	void deleteClaimDetail(int policyClaimNo);
}
