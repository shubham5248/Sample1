package com.farmerproject.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Claim;
import com.farmerproject.demo.entity.Crop;

@Repository
public class CropIMPL extends BaseRepository implements CropRepo {

	Logger logger = LoggerFactory.getLogger(CropIMPL.class);

	public CropIMPL() {

		logger.info("CropIMPL() Constructor... ");
		System.out.println("");
	}

	@Transactional
	public void insertCropDetails(Crop cropObj1) {

		super.persist(cropObj1);

		logger.info("CropDetails inserted...");
	}

	@Override
	public Crop fetchCropDetailsById(int cropId) {

		logger.info("CropIMPL() : selecting CropDetails  by crop Id:");
		Crop cropObj = super.find(Crop.class, cropId);
		return cropObj;
	}

	@Override
	public List<Crop> fetchAllCropDetails() {

		List<Claim> cropObj2 = new ArrayList<Claim>();
		logger.info("CropIMPL(): Selecting all CropDetails ...");

		return super.findAll("Crop");
	}

	@Transactional
	public void updateCropDetail(Crop cropObj2) {
		logger.info("CropIMPL() : Updating CropDetails  ...");
		System.out.println();
		super.merge(cropObj2);
	}

	@Transactional
	public void deleteCropDetailsByID(int cropId) {

		logger.info("CropIMPL(): Deleting CropDetails ");
		System.out.println();
		super.remove(Crop.class, cropId);
	}

}
