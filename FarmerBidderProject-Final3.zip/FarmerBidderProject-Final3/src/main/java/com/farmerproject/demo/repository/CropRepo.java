package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.Crop;


@Repository
public interface CropRepo {
	
	void insertCropDetails(Crop cropObj1);

	Crop fetchCropDetailsById(int cropId);

	List<Crop> fetchAllCropDetails();

	void updateCropDetail(Crop cropObj2);

	void deleteCropDetailsByID(int cropId);
		

}
