package com.farmerproject.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Farmer;

@Repository
public class FarmerIMPL extends BaseRepository implements FarmerRepo {

	Logger logger = LoggerFactory.getLogger(FarmerIMPL.class);

	public FarmerIMPL() {
		logger.info("FarmerIMPL()...");
	}

	@Transactional
	public void insertFarmerDetails(Farmer farmerObj1) {

		super.persist(farmerObj1); // invoking the dummy persist of the super class

		logger.info("FarmerDetails inserted...");
	}

	@Override
	public Farmer fetchFarmerDetailsById(int farmerId) {
		logger.info("FarmerIMPL() : selecting FarmerDetails by farmerId");
		System.out.println();
		Farmer farmerObj = super.find(Farmer.class, farmerId);
		return farmerObj;
	}

	@Override
	public List<Farmer> FetchAllFarmerDetails() {

		List<Farmer> insReqObj2 = new ArrayList<Farmer>();
		logger.info("FarmerIMPL() : Selecting all FarmerDetails...");
		return super.findAll("Farmer");
	}

	@Transactional
	public void updateFarmerDetail(Farmer farmerObj2) {
		logger.info("FarmerIMPL() : Updating FarmerDetails ...");
		super.merge(farmerObj2);
	}

	@Transactional
	public void deleteFarmerDetailsByID(int farmerId) {
		// TODO Auto-generated method stub\
		logger.info("FarmerIMPL()  : Deleting FarmerDetails");

		super.remove(Farmer.class, farmerId);
	}

}
