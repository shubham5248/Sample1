package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.Farmer;



@Repository
public interface FarmerRepo {

	void insertFarmerDetails(Farmer farmerObj1);

	Farmer fetchFarmerDetailsById(int farmerId);

	List<Farmer> FetchAllFarmerDetails();

	void updateFarmerDetail(Farmer farmerObj2);

	void deleteFarmerDetailsByID(int farmerId);

}
