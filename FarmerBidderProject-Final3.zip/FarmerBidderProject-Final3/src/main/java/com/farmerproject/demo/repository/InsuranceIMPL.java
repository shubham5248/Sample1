package com.farmerproject.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Insurance;

@Repository
public class InsuranceIMPL extends BaseRepository implements InsuranceRepo {

	Logger logger = LoggerFactory.getLogger(InsuranceIMPL.class);

	public InsuranceIMPL() {
		logger.info("InsuranceIMPL()  Constructor....");
		System.out.println();
	}

	@Transactional
	public void insertInsurnceRecord(Insurance insuranceObj1) {
		super.persist(insuranceObj1);
		logger.info("insuranceObj1 inserted...");
	}

	@Override
	public Insurance fetchInsuranceRecordById(int policyNo) {
		System.out.println();
		logger.info("InsuranceIMPL : selecting ClaimDetail by ClaimNo");
		Insurance insuranceObj = super.find(Insurance.class, policyNo);
		return insuranceObj;
	}

	@Override
	public List<Insurance> fetchAllInsuranceRecords() {
		List<Insurance> insReqObj2 = new ArrayList<Insurance>();
		logger.info("InsuranceIMPL : Selecting all InsuranceRecords...");
		return super.findAll("Insurance");
	}

	@Transactional
	public void updateInsuranceRecords(Insurance insuranceObj2) {
		logger.info("InsuranceIMPL : Updating InsuranceRecords ...");
		super.merge(insuranceObj2);
	}

	@Transactional
	public void deleteInsuranceRecord(int policyNo) {
		logger.info("InsuranceIMPL : Deleting InsuranceRecords");
		super.remove(Insurance.class, policyNo);
	}

}
