package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.Insurance;



@Repository
public interface InsuranceRepo {
	void insertInsurnceRecord(Insurance insuranceObj1);

	Insurance fetchInsuranceRecordById(int policyNo);

	List<Insurance> fetchAllInsuranceRecords();

	void updateInsuranceRecords(Insurance insuranceObj2);

	void deleteInsuranceRecord(int policyNo);

}
