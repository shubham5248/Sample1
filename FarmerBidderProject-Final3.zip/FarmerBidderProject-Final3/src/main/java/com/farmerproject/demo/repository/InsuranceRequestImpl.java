package com.farmerproject.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.InsuranceRequest;

@Repository
public class InsuranceRequestImpl extends BaseRepository implements InsuranceRequestRepository {

	Logger logger = LoggerFactory.getLogger(InsuranceRequestImpl.class);

	public InsuranceRequestImpl() {
		logger.info("InsuranceRequestImpl Constructor()..");

	}

	@Transactional
	public void insertInsuranceRequest(InsuranceRequest insReqObj1) {
		super.persist(insReqObj1);
		logger.info("InsuranceRequest inserted...");
	}

	@Override
	public InsuranceRequest selectInsuranceRequest(int insReqNo) {
		System.out.println();
		logger.info("InsuranceRequestImpl : selecting InsuranceRequest by Request Number");
		InsuranceRequest insReqObj = super.find(InsuranceRequest.class, insReqNo);
		return insReqObj;
	}

	@Override
	public List<InsuranceRequest> selectInsuranceRequest() {
		List<InsuranceRequest> insReqObj2 = new ArrayList<InsuranceRequest>();
		logger.info("InsuranceRequestImpl : Selecting all InsuranceRequests...");
		return super.findAll("InsuranceRequest");
	}

	@Transactional
	public void updateInsuranceRequest(InsuranceRequest insReqObj2) {
		logger.info("InsuranceRequestImpl : Updating InsuranceRequest ...");
		super.merge(insReqObj2);

	}

	@Transactional
	public void deleteInsuranceRequest(int insReqNo) {
		logger.info("InsuranceRequestImpl : Deleting InsuranceRequest");
		super.remove(InsuranceRequest.class, insReqNo);

	}

}
