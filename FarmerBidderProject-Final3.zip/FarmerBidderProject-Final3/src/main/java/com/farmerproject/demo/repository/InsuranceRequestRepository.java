package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.InsuranceRequest;



@Repository
public interface InsuranceRequestRepository {
	void insertInsuranceRequest(InsuranceRequest insReqObj1);

	InsuranceRequest selectInsuranceRequest(int insReqNo);

	List<InsuranceRequest> selectInsuranceRequest();

	void updateInsuranceRequest(InsuranceRequest insReqObj2);

	void deleteInsuranceRequest(int insReqNo);
}
