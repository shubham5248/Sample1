package com.farmerproject.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.PolicyDetails;

@Repository
public class PolicyDetailsIMPL extends BaseRepository implements PolicyDetailsRepository {

	Logger logger = LoggerFactory.getLogger(PolicyDetailsIMPL.class);

	public PolicyDetailsIMPL() {
		logger.info("PolicyDetailsIMPL Constructor()..");
	}

	@Transactional
	public void insertPolicyDetails(PolicyDetails policyDetailObj2) {
		super.persist(policyDetailObj2);
		logger.info("PolicyDetailsIMPL:PolicyDetails inserted...");
	}

	@Override
	public PolicyDetails selectPolicyDetails(int policyDetailNo) {
		logger.info("PolicyDetailsIMPL:Selecting Policy Detailsby Id...");
		PolicyDetails policyDetailObj = super.find(PolicyDetails.class, policyDetailNo);
		return policyDetailObj;
	}

	@Override
	public List<PolicyDetails> selectPolicyDetails() {
		List<PolicyDetails> policyDetailObj = new ArrayList<PolicyDetails>();
		logger.info("PolicyDetailsIMPL : Selecting all PolicyDetails...");
		return super.findAll("PolicyDetails");
	}

	@Transactional
	public void updatePolicyDetail(PolicyDetails policyDetailObj2) {
		System.out.println();
		logger.info("PolicyDetailsIMPL : Updating PolicyDetails ...");
		super.merge(policyDetailObj2);
	}

	@Transactional
	public void deletePolicyDetail(int insPolicyNo) {
		System.out.println("PolicyDetailsIMPL : Deleting PolicyDetails");
		super.remove(PolicyDetails.class, insPolicyNo);
	}

}
