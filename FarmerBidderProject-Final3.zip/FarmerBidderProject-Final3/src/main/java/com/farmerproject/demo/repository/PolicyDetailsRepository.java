package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.PolicyDetails;


@Repository
public interface PolicyDetailsRepository {
	void insertPolicyDetails(PolicyDetails policyDetailObj2);

	PolicyDetails selectPolicyDetails(int policyDetailNo);

	List<PolicyDetails> selectPolicyDetails();

	void updatePolicyDetail(PolicyDetails policyDetailObj2);

	void deletePolicyDetail(int insPolicyNo);

}
