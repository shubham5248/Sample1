package com.farmerproject.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.RequestBid;

@Repository
public class RequestBidIMPL extends BaseRepository implements RequestBidRepo {

	Logger logger = LoggerFactory.getLogger(RequestBidIMPL.class);

	public RequestBidIMPL() {
		logger.info("RequestBidIMPL:Constructor");

	}

	@Transactional
	public void insertRequestBid(RequestBid requestBidObj1) {
		super.persist(requestBidObj1);
		logger.info("RequestBidRecord inserted...");
	}

	@Override
	public RequestBid fetchRequestBidById(int bidRequestNo) {
		System.out.println();
		logger.info("RequestBidIMPL() : selecting RequestBidRecord by farmerId");
		RequestBid requestBidObj = super.find(RequestBid.class, bidRequestNo);
		return requestBidObj;
	}

	@Override
	public List<RequestBid> fetchAllRequestBidRecord() {
		List<RequestBid> insReqObj2 = new ArrayList<RequestBid>();
		logger.info("RequestBidIMPL() : Selecting all RequestBidRecords...");
		return super.findAll("RequestBid");
	}

	@Transactional
	public void updateRequestBidRecord(RequestBid requestBidObj2) {
		logger.info("RequestBidIMPL() : Updating RequestBidRecord ...");
		super.merge(requestBidObj2);
	}

	@Transactional
	public void deleteRequestBidRecord(int bidRequestNo) {
		logger.info("RequestBidIMPL()  : Deleting RequestBidRecord");
		System.out.println();
		super.remove(RequestBid.class, bidRequestNo);
	}

}
