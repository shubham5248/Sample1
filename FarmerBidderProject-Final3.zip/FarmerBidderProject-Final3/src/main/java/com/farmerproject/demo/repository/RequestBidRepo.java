package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.RequestBid;



@Repository
public interface RequestBidRepo {
	
	void insertRequestBid(RequestBid requestBidObj1);

	RequestBid fetchRequestBidById(int bidRequestNo);

	List<RequestBid> fetchAllRequestBidRecord();

	void updateRequestBidRecord(RequestBid requestBidObj2);

	void deleteRequestBidRecord(int bidRequestNo);

}
