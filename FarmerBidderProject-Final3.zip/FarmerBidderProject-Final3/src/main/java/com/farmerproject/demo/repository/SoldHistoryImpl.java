package com.farmerproject.demo.repository;

import java.util.List;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.SoldHistory;

@Repository
public class SoldHistoryImpl  extends BaseRepository implements SoldHistoryRepo{

	@Transactional
	public void insertSoldHistory(SoldHistory shobj) {
		// TODO Auto-generated method stub
		super.persist(shobj);
		
	}

	@Transactional
	public void deleteSoldHistory(int bid) {
		// TODO Auto-generated method stub
		super.remove(SoldHistory.class, bid);
	}

	@Transactional
	public void updateSoldHistory(SoldHistory shobj) {
		// TODO Auto-generated method stub
		
		super.merge(shobj);
		
	}

	@Override
	public SoldHistory selectSoldHistory(int bid) {
		// TODO Auto-generated method stub
		return super.find(SoldHistory.class, bid);
	}

	@Override
	public List<SoldHistory> selectSoldHistorys() {
		// TODO Auto-generated method stub
		return super.findAll("SoldBidder");
	}
	
	
	

}
