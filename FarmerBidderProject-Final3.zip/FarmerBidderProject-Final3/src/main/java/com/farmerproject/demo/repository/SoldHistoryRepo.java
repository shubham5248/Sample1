package com.farmerproject.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.farmerproject.demo.entity.SoldHistory;

@Repository
public interface SoldHistoryRepo {
	
	
	void insertSoldHistory(SoldHistory shobj);
	
	void  deleteSoldHistory(int bid);
	
	void updateSoldHistory(SoldHistory shobj);
	
	SoldHistory selectSoldHistory (int bid);
	
	List<SoldHistory> selectSoldHistorys();
	
	
	

}
