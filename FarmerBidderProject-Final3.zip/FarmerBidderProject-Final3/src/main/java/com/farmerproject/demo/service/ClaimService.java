package com.farmerproject.demo.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.Claim;

@Service

public interface ClaimService {

	public List<Claim> getClaimDetails();

	public void insertClaimDetails(Claim claimObj);

	public void updateClaimDetails(Claim claimObj);

	public void deleteClaimDetails(int id);

	public Claim fetchClaimDetailsById(int claimid);


}
