package com.farmerproject.demo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Claim;
import com.farmerproject.demo.repository.ClaimIMPL;

@Service
public class ClaimServiceIMPL implements ClaimService {

	Logger logger = LoggerFactory.getLogger(ClaimServiceIMPL.class);
	@Autowired
	ClaimIMPL claimRepo;

	
	
	@Override
	public Claim fetchClaimDetailsById(int claimid) {
		logger.info("ClaimServiceIMPL:Selecting single claim Details");
		return claimRepo.fetchClaimDetailsById(claimid);
	}
	@Override
	public List<Claim> getClaimDetails() {
		logger.info("ClaimServiceIMPL::Fetching all claim Details...");
		return claimRepo.selectClaimDetails();
	}

	@Transactional
	public void insertClaimDetails(Claim claimObj) {
		logger.info("ClaimServiceIMPL: Inserting claim details");
		claimRepo.insertClaimDetails(claimObj);
	}

	@Transactional
	public void updateClaimDetails(Claim claimObj) {
		logger.info("ClaimServiceIMPL:Updating claim details");
		claimRepo.updateClaimDetail(claimObj);
	}

	@Transactional
	public void deleteClaimDetails(int id) {
		logger.info("ClaimServiceIMPL:Deleting one claim details");
		claimRepo.deleteClaimDetail(id);
	}

	

}
