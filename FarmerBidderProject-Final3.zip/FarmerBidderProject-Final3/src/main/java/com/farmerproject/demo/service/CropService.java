package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.Crop;

@Service
public interface CropService {

	public List<Crop> getCropDetails();

	public void insertCrop(Crop cropObj);

	public void updateCropDetails(Crop cropObj);

	public void deleteCropDetails(int id);

	public Crop fetchById(int cropid);

	// public Optional<Crop> getApplicationDetails(int id);
}
