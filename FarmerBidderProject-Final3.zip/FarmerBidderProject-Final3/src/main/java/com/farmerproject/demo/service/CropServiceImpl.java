package com.farmerproject.demo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Crop;
import com.farmerproject.demo.repository.CropIMPL;

@Service
public class CropServiceImpl implements CropService {

	Logger logger=LoggerFactory.getLogger(CropServiceImpl.class);
	@Autowired
	CropIMPL cropRepo;
	
	@Override
	public Crop fetchById(int cropid) {
logger.info("CropServiceIMPL:Fetching Single Crop Details....");
return cropRepo.fetchCropDetailsById(cropid);
	}
	
	@Override
	public List<Crop> getCropDetails() {
		logger.info("CropServiceIMPL:Fetching all Crop Records...");
		return cropRepo.fetchAllCropDetails();
	}

	@Transactional
	public void insertCrop(Crop cropObj) {
		logger.info("CropServiceIMPL:Inserting Crop Record...");
		cropRepo.insertCropDetails(cropObj);
	}

	@Transactional
	public void updateCropDetails(Crop cropObj) {
		logger.info("CropServiceIMPL: Updating crop Record...");
		cropRepo.insertCropDetails(cropObj);

	}

	@Transactional
	public void deleteCropDetails(int id) {
		logger.info("CropServiceIMPL:Deleting Crop Record...");
		cropRepo.deleteCropDetailsByID(id);

	}

//	@Override
//	public Optional<Crop> getApplicationDetails(int id) {
//		// TODO Auto-generated method stub
//		return Optional.of(cropRepo.fetchCropDetailsById(id));
//	}

	

}
