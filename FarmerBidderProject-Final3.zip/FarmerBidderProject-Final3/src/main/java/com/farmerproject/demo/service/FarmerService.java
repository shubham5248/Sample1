package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.Farmer;

@Service
public interface FarmerService {

	public List<Farmer> getFarmerDetails();

	public void insertFarmerDetails(Farmer farmerObj);

	public void updateFarmerDetails(Farmer farmerObj);

	public void deleteFarmerDetails(int FarmerId);

	public Farmer fetchFarmerDetailsById(int farmerId);

}
