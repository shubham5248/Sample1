package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Farmer;
import com.farmerproject.demo.repository.FarmerIMPL;

@Service
public class FarmerServiceIMPL implements FarmerService {

	@Autowired
	FarmerIMPL farmerService;

	@Override
	public List<Farmer> getFarmerDetails() {
		// TODO Auto-generated method stub
		return farmerService.FetchAllFarmerDetails();
	}

	@Transactional
	public void insertFarmerDetails(Farmer farmerObj) {
		// TODO Auto-generated method stub
		farmerService.insertFarmerDetails(farmerObj);
	}

	@Transactional
	public void updateFarmerDetails(Farmer farmerObj) {
		// TODO Auto-generated method stub
		farmerService.updateFarmerDetail(farmerObj);
	}

	@Transactional
	public void deleteFarmerDetails(int FarmerId) {
		// TODO Auto-generated method stub
		farmerService.deleteFarmerDetailsByID(FarmerId);
	}

	@Override
	public Farmer fetchFarmerDetailsById(int farmerId) {
		// TODO Auto-generated method stub
		return farmerService.fetchFarmerDetailsById(farmerId);
	}

}
