package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.InsuranceRequest;

@Service
public interface InsuranceRequestService {

	public List<InsuranceRequest> getInsuranceRequestDetails();

	public void insertInsuranceRequestDetails(InsuranceRequest insuranceReqObj);

	public void updateInsuranceRequestDetails(InsuranceRequest insuranceReqObj);

	public void deleteInsuranceRequestDetails(int requestno);

	public InsuranceRequest fetchInsuranceRequestDetailsByrequestno(int requestno);
}
