package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.InsuranceRequest;
import com.farmerproject.demo.repository.InsuranceRequestImpl;

@Service
public class InsuranceRequestServiceIMPL implements InsuranceRequestService {

	@Autowired
	InsuranceRequestImpl insuranceReqRepo;

	@Override
	public List<InsuranceRequest> getInsuranceRequestDetails() {
		// TODO Auto-generated method stub
		return insuranceReqRepo.selectInsuranceRequest();
	}

	@Transactional
	public void insertInsuranceRequestDetails(InsuranceRequest insuranceReqObj) {
		// TODO Auto-generated method stub

		insuranceReqRepo.insertInsuranceRequest(insuranceReqObj);
	}

	@Transactional
	public void updateInsuranceRequestDetails(InsuranceRequest insuranceReqObj) {
		// TODO Auto-generated method stub

		insuranceReqRepo.updateInsuranceRequest(insuranceReqObj);
	}

	@Transactional
	public void deleteInsuranceRequestDetails(int requestno) {
		// TODO Auto-generated method stub

		insuranceReqRepo.deleteInsuranceRequest(requestno);
	}

	@Override
	public InsuranceRequest fetchInsuranceRequestDetailsByrequestno(int requestno) {
		// TODO Auto-generated method stub
		return insuranceReqRepo.selectInsuranceRequest(requestno);
	}

}
