package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.Insurance;

@Service
public interface InsuranceService {
	public List<Insurance> getInsuranceDetails();

	public void insertInsuranceDetails(Insurance insuranceObj);

	public void updateInsuranceDetails(Insurance insuranceObj);

	public void deleteInsuranceDetails(int policyNumber);

	public Insurance fetchInsuranceDetailsBypolicyNumber(int policyNumber);

}
