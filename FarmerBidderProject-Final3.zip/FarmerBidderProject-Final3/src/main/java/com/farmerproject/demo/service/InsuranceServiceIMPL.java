package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.Insurance;
import com.farmerproject.demo.repository.InsuranceIMPL;

@Service
public class InsuranceServiceIMPL implements InsuranceService {

	@Autowired
	InsuranceIMPL insuranceRepo;

	@Override
	public List<Insurance> getInsuranceDetails() {
		// TODO Auto-generated method stub
		return insuranceRepo.fetchAllInsuranceRecords();
	}

	@Transactional
	public void insertInsuranceDetails(Insurance insuranceObj) {
		// TODO Auto-generated method stub

		insuranceRepo.insertInsurnceRecord(insuranceObj);

	}

	@Transactional
	public void updateInsuranceDetails(Insurance insuranceObj) {
		// TODO Auto-generated method stub
		insuranceRepo.updateInsuranceRecords(insuranceObj);
	}

	@Transactional
	public void deleteInsuranceDetails(int policyNumber) {
		// TODO Auto-generated method stub
		insuranceRepo.deleteInsuranceRecord(policyNumber);

	}

	@Override
	public Insurance fetchInsuranceDetailsBypolicyNumber(int policyNumber) {
		// TODO Auto-generated method stub
		return insuranceRepo.fetchInsuranceRecordById(policyNumber);
	}

}
