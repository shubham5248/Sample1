package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.PolicyDetails;

@Service
public interface PolicyDetailsService {
	public List<PolicyDetails> getPolicyDetails();

	public void insertPolicyDetails(PolicyDetails policyObj);

	public void updatePolicyDetails(PolicyDetails policyDetailsObj);

	public void deletePolicyDetails(int policyNumber);

	public PolicyDetails fetchPolicyDetailsByPolicyNumber(int policyNumber);

}
