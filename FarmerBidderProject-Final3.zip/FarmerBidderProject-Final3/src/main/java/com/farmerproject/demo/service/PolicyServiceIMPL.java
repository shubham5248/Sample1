package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.PolicyDetails;
import com.farmerproject.demo.repository.PolicyDetailsIMPL;

@Service
public class PolicyServiceIMPL implements PolicyDetailsService {

	@Autowired
	PolicyDetailsIMPL policyRepo;

	@Override
	public List<PolicyDetails> getPolicyDetails() {
		// TODO Auto-generated method stub
		return policyRepo.selectPolicyDetails();
	}

	@Transactional
	public void insertPolicyDetails(PolicyDetails policyObj) {
		// TODO Auto-generated method stub
		policyRepo.insertPolicyDetails(policyObj);
	}

	@Transactional
	public void updatePolicyDetails(PolicyDetails policyDetailsObj) {
		// TODO Auto-generated method stub
		policyRepo.updatePolicyDetail(policyDetailsObj);
	}

	@Transactional
	public void deletePolicyDetails(int policyNumber) {
		// TODO Auto-generated method stub

		policyRepo.deletePolicyDetail(policyNumber);

	}

	@Override
	public PolicyDetails fetchPolicyDetailsByPolicyNumber(int policyNumber) {
		// TODO Auto-generated method stub
		return policyRepo.selectPolicyDetails(policyNumber);
	}

}
