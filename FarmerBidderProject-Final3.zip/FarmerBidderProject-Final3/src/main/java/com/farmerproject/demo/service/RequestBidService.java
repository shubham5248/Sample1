package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.RequestBid;

@Service
public interface RequestBidService {

	public List<RequestBid> getRequestBidDetails();

	public void insertRequestBidDetails(RequestBid requestBidObj);

	public void updateRequestBidDetails( RequestBid requestBidObj);

	public void deleteRequestBidDetails(int requestNo);

	public RequestBid fetchRequestBidDetailsById(int requestNo);

}
