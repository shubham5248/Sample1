package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farmerproject.demo.entity.RequestBid;
import com.farmerproject.demo.repository.RequestBidIMPL;

@Service
public class RequestBidServiceIMPL implements RequestBidService {

	@Autowired
	RequestBidIMPL requestBidRepo;

	@Override
	public List<RequestBid> getRequestBidDetails() {

		return requestBidRepo.fetchAllRequestBidRecord();
	}

	@Transactional
	public void insertRequestBidDetails(RequestBid requestBidObj) {

		requestBidRepo.insertRequestBid(requestBidObj);

	}

	@Transactional
	public void updateRequestBidDetails(RequestBid requestBidObj) {
		requestBidRepo.updateRequestBidRecord(requestBidObj);
	}

	@Transactional
	public void deleteRequestBidDetails(int requestNo) {
		requestBidRepo.deleteRequestBidRecord(requestNo);
	}

	@Override
	public RequestBid fetchRequestBidDetailsById(int requestNo) {
		return requestBidRepo.fetchRequestBidById(requestNo);
	}

}
