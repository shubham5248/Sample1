package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.Bidder;


@Service
interface ServiceBidderRepo {
	
	void insertBidder(Bidder bobj);
	
	void updateBidder (Bidder bobj);
	
	Bidder selectBidder(int b_bid);
	
	List<Bidder> selectAllBidder();
	
	void removeBidder(int b_bid);
}
