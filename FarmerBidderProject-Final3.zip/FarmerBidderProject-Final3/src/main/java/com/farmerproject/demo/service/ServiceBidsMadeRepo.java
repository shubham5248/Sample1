package com.farmerproject.demo.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.Bids_Made;



@Service
interface ServiceBidsMadeRepo {

	
	public void insertBidsMade (Bids_Made Bids_Made);
	
	public void  updateBidsMade( Bids_Made bidMade);
	
	public void deleteBidsMade (int b_bidding_id);
	
	public Bids_Made selectBidsMade ( int b_bidding_id);
	
	public List<Bids_Made> selectAllBidsMade();

}
