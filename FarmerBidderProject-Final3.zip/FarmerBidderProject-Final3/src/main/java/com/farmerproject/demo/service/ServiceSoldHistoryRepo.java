package com.farmerproject.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.farmerproject.demo.entity.SoldHistory;



    @Service
    public interface ServiceSoldHistoryRepo {
	
    public void insertSoldHistory (SoldHistory soldHistory);
	
	public void  updateSoldHistory( SoldHistory soldHistory);
	
	public void deleteSoldHistory (int SrNo);
	
	public SoldHistory selectSoldHistory ( int SrNo);
	
	public List<SoldHistory> selectAllSoldHistory();
}
