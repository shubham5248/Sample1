package com.farmerproject.demo;



import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Claim;
import com.farmerproject.demo.repository.ClaimIMPL;

@SpringBootTest
public class ClaimTest {

	@Autowired
	ClaimIMPL claimRepo;

	@Test
	void insertClaimDetail() {
		LocalDate localdateObj = LocalDate.of(2019, 5, 1);
		Claim claimObj = new Claim();
		claimObj.setReason("accident");
		claimObj.setDateOfClaim(localdateObj);

		claimRepo.insertClaimDetails(claimObj);

	}

	@Test
	public void updateClaimDetail() {
		LocalDate lds = LocalDate.of(1998, 9, 8);
		Claim claimDetailsObj = null;
		claimDetailsObj = claimRepo.find(Claim.class, 16);
		claimDetailsObj.setReason("ABC");
		claimDetailsObj.setDateOfClaim(lds);
		claimRepo.merge(claimDetailsObj);

	}

	@Test
	public void deleteClaimDetail() {
		Claim claimDetailObj = new Claim();
		claimRepo.deleteClaimDetail(19);
	}

	@Test
	public void fetchClaimDetailsById() {
		Claim claimDetailsObj;
		claimDetailsObj = claimRepo.fetchClaimDetailsById(15);
		System.out.println("-----------------------------------------");
		System.out.println("Policy Details policyNum is " + claimDetailsObj.getPolicyNum());
		System.out.println("Claim reason is  : " + claimDetailsObj.getReason());
		System.out.println("DAte of claim is " + claimDetailsObj.getDateOfClaim());

		System.out.println("-----------------------------------------");

	}

	@Test
	public void fetchAllClaimDetails() {
		List<Claim> claimDetailsList;
		claimDetailsList = claimRepo.selectClaimDetails();
		for (Claim claimDetailsObj : claimDetailsList) {
			System.out.println("-----------------------------------------");
			System.out.println("Policy Details policyNum is " + claimDetailsObj.getPolicyNum());
			System.out.println("Claim reason is  : " + claimDetailsObj.getReason());
			System.out.println("DAte of claim is " + claimDetailsObj.getDateOfClaim());

			System.out.println("-----------------------------------------");
		}

	}
}