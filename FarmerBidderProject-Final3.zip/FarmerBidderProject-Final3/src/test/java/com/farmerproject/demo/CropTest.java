package com.farmerproject.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Crop;
import com.farmerproject.demo.repository.CropIMPL;

@SpringBootTest
public class CropTest {

	@Autowired
	CropIMPL cropRepo;

	@Test
	void insertCropDetails() {

		Crop cropObj = new Crop();
//        cropObj.setCropId(52);
		cropObj.setCropType("RABI");
		cropObj.setCropPremium(555.60);
		cropObj.setCropMsp(66000.3);
		cropObj.setCropBasePrice(50000.5);
		cropObj.setCurrentPrice(40000.0);
		cropRepo.insertCropDetails(cropObj);

	}

	@Test
	public void updateCropDetail() {

		Crop cropObj = null;
		cropObj = cropRepo.find(Crop.class, 48);
		cropObj.setCropType("Kharip");
		cropObj.setCropPremium(666.60);
		cropObj.setCropMsp(99000.3);
		cropObj.setCropBasePrice(50000.5);
		cropObj.setCurrentPrice(40000.0);
		cropRepo.updateCropDetail(cropObj);

	}

	@Test
	public void deleteClaimDetail() {
		Crop cropObj = new Crop();

		cropRepo.deleteCropDetailsByID(49);
	}

	@Test
	public void fetchCropDetailsById() {
		Crop cropObj;
		cropObj = cropRepo.fetchCropDetailsById(47);
		System.out.println("-----------------------------------------");
		System.out.println("Crop Id Is :" + cropObj.getCropId());
		System.out.println("Crop Premium Is :" + cropObj.getCropPremium());
		System.out.println("Crop MSP Is :" + cropObj.getCropMsp());
		System.out.println("Crop Base Price Is :" + cropObj.getCropBasePrice());
		System.out.println("Crop CurrentPrice Is :" + cropObj.getCurrentPrice());

		System.out.println("-----------------------------------------");

	}

	@Test
	public void fetchAllClaimDetails() {
		List<Crop> cropDetailsList;
		cropDetailsList = cropRepo.fetchAllCropDetails();
		for (Crop cropObj : cropDetailsList) {
			System.out.println("-----------------------------------------");
			System.out.println("Crop Id Is :" + cropObj.getCropId());
			System.out.println("Crop Premium Is :" + cropObj.getCropPremium());
			System.out.println("Crop MSP Is :" + cropObj.getCropMsp());
			System.out.println("Crop Base Price Is :" + cropObj.getCropBasePrice());
			System.out.println("Crop CurrentPrice Is :" + cropObj.getCurrentPrice());

			System.out.println("-----------------------------------------");
		}

	}

}
