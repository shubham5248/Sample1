package com.farmerproject.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerBidderProjectFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
