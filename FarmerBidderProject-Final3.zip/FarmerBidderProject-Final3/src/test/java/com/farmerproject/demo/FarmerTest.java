package com.farmerproject.demo;



import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Farmer;
import com.farmerproject.demo.repository.FarmerIMPL;

@SpringBootTest
public class FarmerTest {

	@Autowired
	FarmerIMPL farmerRepo;

	@Test
	public void insertFarmerDetails() {
		Farmer farmerObj = new Farmer();
//		farmerObj.setFarmerId(11);
		farmerObj.setFarmerName("Lakhan");
		farmerObj.setFarmerEmail("lakhan@gmail.com");
		farmerObj.setFarmerContact(9975808107l);
		farmerObj.setFarmerHomeAddress("Velapur");
		farmerObj.setFarmerPinCode(413113);
		farmerObj.setFarmerCity("Velapur");
		farmerObj.setFarmerState("MH");
		farmerObj.setFarmerAadharCard(123456789123l);
		farmerObj.setFarmerArea("Outside village");
		farmerObj.setFarmerLandAddress("Akluj");
		farmerObj.setFarmerLandPinCode(123456);
		farmerObj.setFarmerLandCity("malewadi");
		farmerObj.setFarmerLandPinCode(987654321789l);
		farmerObj.setFarmerLandState("MH");
		farmerObj.setFarmerAccountNumber(23158499947689l);
		farmerObj.setFarmerBanfIFSCcode(125125741258l);
		farmerObj.setFarmerBank("BOB");

		farmerRepo.insertFarmerDetails(farmerObj);

	}

	@Test
	public void updateFarmerDetail() {
		Farmer farmerObj = null;
		farmerObj = farmerRepo.find(Farmer.class, 33);
		farmerObj.setFarmerName("Makrand");
		farmerObj.setFarmerEmail("makrand@gmail.com");
		farmerObj.setFarmerContact(9975808107l);
		farmerObj.setFarmerHomeAddress("Velapur");
		farmerObj.setFarmerPinCode(413113);
		farmerObj.setFarmerCity("Velapur");
		farmerObj.setFarmerState("MH");
		farmerObj.setFarmerAadharCard(123456789123l);
		farmerObj.setFarmerArea("Outside village");
		farmerObj.setFarmerLandAddress("Akluj");
		farmerObj.setFarmerLandPinCode(123456);
		farmerObj.setFarmerLandCity("malewadi");
		farmerObj.setFarmerLandPinCode(987654321789l);
		farmerObj.setFarmerLandState("MH");
		farmerObj.setFarmerAccountNumber(23158499947689l);
		farmerObj.setFarmerBanfIFSCcode(125125741258l);
		farmerObj.setFarmerBank("BOB");
		farmerRepo.merge(farmerObj);

	}

	@Test
	public void deleteFarmerDetail() {
		Farmer farmerObj = new Farmer();
		farmerRepo.deleteFarmerDetailsByID(38);
	}

	@Test
	public void fetchInsuranceRecordById() {
		Farmer farmerObj;
		farmerObj = farmerRepo.fetchFarmerDetailsById(33);
		System.out.println("-----------------------------------------");

		System.out.println("Farmer  ID    		  : " + farmerObj.getFarmerId());
		System.out.println("Farmer  Name 		   : " + farmerObj.getFarmerName());
		System.out.println("Farmer  Email   		 : " + farmerObj.getFarmerEmail());
		System.out.println("Farmer  ContactNO.  	  : " + farmerObj.getFarmerContact());
		System.out.println("Farmer  Home Address  	  : " + farmerObj.getFarmerHomeAddress());
		System.out.println("Farmer  Pin code  		  : " + farmerObj.getFarmerPinCode());
		System.out.println("Farmer  city    			: " + farmerObj.getFarmerState());
		System.out.println("Farmer  state    : " + farmerObj.getFarmerState());
		System.out.println("Farmer  Aadhar Card    : " + farmerObj.getFarmerAadharCard());
		System.out.println("Farmer  Farmer  Area    : " + farmerObj.getFarmerArea());
		System.out.println("Farmer  Land Address    : " + farmerObj.getFarmerLandAddress());
		System.out.println("Farmer  Land Pin      : " + farmerObj.getFarmerLandPinCode());
		System.out.println("Farmer  Land City      : " + farmerObj.getFarmerLandCity());
		System.out.println("Farmer  Land State      : " + farmerObj.getFarmerLandState());

		System.out.println("Farmer  farmerAccountNumber     : " + farmerObj.getFarmerAccountNumber());
		System.out.println("Farmer  farmerBanfIFSCcode     : " + farmerObj.getFarmerBanfIFSCcode());
		System.out.println("-----------------------------------------");

	}

	@Test
	public void fetchAllInsuranceRecords() {
		List<Farmer> farmerDetailsList;
		farmerDetailsList = farmerRepo.FetchAllFarmerDetails();
		for (Farmer farmerObj : farmerDetailsList) {
			System.out.println("-----------------------------------------");

			System.out.println("Farmer  ID    		  : " + farmerObj.getFarmerId());
			System.out.println("Farmer  Name 		   : " + farmerObj.getFarmerName());
			System.out.println("Farmer  Email   		 : " + farmerObj.getFarmerEmail());
			System.out.println("Farmer  ContactNO.  	  : " + farmerObj.getFarmerContact());
			System.out.println("Farmer  Home Address  	  : " + farmerObj.getFarmerHomeAddress());
			System.out.println("Farmer  Pin code  		  : " + farmerObj.getFarmerPinCode());
			System.out.println("Farmer  city    			: " + farmerObj.getFarmerState());
			System.out.println("Farmer  state    : " + farmerObj.getFarmerState());
			System.out.println("Farmer  Aadhar Card    : " + farmerObj.getFarmerAadharCard());
			System.out.println("Farmer  Farmer  Area    : " + farmerObj.getFarmerArea());
			System.out.println("Farmer  Land Address    : " + farmerObj.getFarmerLandAddress());
			System.out.println("Farmer  Land Pin      : " + farmerObj.getFarmerLandPinCode());
			System.out.println("Farmer  Land City      : " + farmerObj.getFarmerLandCity());
			System.out.println("Farmer  Land State      : " + farmerObj.getFarmerLandState());

			System.out.println("Farmer  farmerAccountNumber     : " + farmerObj.getFarmerAccountNumber());
			System.out.println("Farmer  farmerBanfIFSCcode     : " + farmerObj.getFarmerBanfIFSCcode());

			System.out.println("-----------------------------------------");
		}
	}

}