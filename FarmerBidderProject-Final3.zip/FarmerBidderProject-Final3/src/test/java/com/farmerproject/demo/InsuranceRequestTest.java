package com.farmerproject.demo;


import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.InsuranceRequest;
import com.farmerproject.demo.repository.InsuranceRequestImpl;

@SpringBootTest
public class InsuranceRequestTest {

	@Autowired
	InsuranceRequestImpl insuranceReqRepo1;

	@Test
	public void insertInsuranceReq_policyDetails() {

		LocalDate lds = LocalDate.of(1998, 9, 8);

		InsuranceRequest req = new InsuranceRequest();

		req.setiFid(102);
		req.setIseason("Rabi");
		req.setIld(lds);
		req.setiCrop("Wheat");
		req.setiSumInsured(200.4f);
		req.setiCompany("LIC");
		req.setiNomineeName("Lakhan");
		req.setiLandArea("south");
		req.setiPreAmount(5000f);

		insuranceReqRepo1.insertInsuranceRequest(req);

	}

	@Test
	public void updateInsuranceRequestDetails() {
		LocalDate lds = LocalDate.of(1998, 9, 8);
		InsuranceRequest req = null;
		req = insuranceReqRepo1.find(InsuranceRequest.class, 109);
		req.setiFid(102);
		req.setIseason("Kharip");
		req.setIld(lds);
		req.setiCrop("Rice");
		req.setiSumInsured(200.4f);
		req.setiCompany("PACL");
		req.setiNomineeName("Sham");
		req.setiLandArea("south");
		req.setiPreAmount(5000f);
		insuranceReqRepo1.updateInsuranceRequest(req);

	}

	@Test
	public void deleteInsuranceRequest() {
		InsuranceRequest req = new InsuranceRequest();
		insuranceReqRepo1.deleteInsuranceRequest(114);

	}

	@Test
	public void fetchInsuranceRequestBtId() {
		InsuranceRequest insuranceReqObj;
		insuranceReqObj = insuranceReqRepo1.selectInsuranceRequest(109);
		System.out.println("Insurance Request Id is :" + insuranceReqObj.getPdRequestNo());
		System.out.println("Insurance Request FId is :" + insuranceReqObj.getiFid());
		System.out.println("Insurance Request insuranceSeason is :" + insuranceReqObj.getIseason());
		System.out.println("Insurance Request insurance Request date  is :" + insuranceReqObj.getIld());
		System.out.println("Insurance Request crop is :" + insuranceReqObj.getiCrop());
		System.out.println("Insurance Request sum insured   amt is :" + insuranceReqObj.getiSumInsured());
		System.out.println("Insurance Request compony is :" + insuranceReqObj.getiCompany());
		System.out.println("Insurance Request nominee name is :" + insuranceReqObj.getiNomineeName());
		System.out.println("Insurance Request LandArea  is :" + insuranceReqObj.getiLandArea());
		System.out.println("Insurance Request PreAmount is :" + insuranceReqObj.getiPreAmount());
		System.out.println("-----------------------------------------");

	}

	@Test
	public void fetchAllInsuranceRequest() {
		List<InsuranceRequest> insuranceRequestList;
		insuranceRequestList = insuranceReqRepo1.selectInsuranceRequest();
		for (InsuranceRequest insuranceReqObj : insuranceRequestList) {
			System.out.println("Insurance Request Id is :" + insuranceReqObj.getPdRequestNo());
			System.out.println("Insurance Request FId is :" + insuranceReqObj.getiFid());
			System.out.println("Insurance Request insuranceSeason is :" + insuranceReqObj.getIseason());
			System.out.println("Insurance Request insurance Request date  is :" + insuranceReqObj.getIld());
			System.out.println("Insurance Request crop is :" + insuranceReqObj.getiCrop());
			System.out.println("Insurance Request sum insured   amt is :" + insuranceReqObj.getiSumInsured());
			System.out.println("Insurance Request compony is :" + insuranceReqObj.getiCompany());
			System.out.println("Insurance Request nominee name is :" + insuranceReqObj.getiNomineeName());
			System.out.println("Insurance Request LandArea  is :" + insuranceReqObj.getiLandArea());
			System.out.println("Insurance Request PreAmount is :" + insuranceReqObj.getiPreAmount());
			System.out.println("-----------------------------------------");

		}
	}

}