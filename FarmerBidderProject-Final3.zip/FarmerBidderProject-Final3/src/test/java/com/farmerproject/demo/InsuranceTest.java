package com.farmerproject.demo;


import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Insurance;
import com.farmerproject.demo.repository.InsuranceIMPL;

@SpringBootTest
public class InsuranceTest {

	@Autowired
	InsuranceIMPL insuranceRepo;

	@Test
	public void insertInsuranceRecord() {
		Insurance insuranceObj = new Insurance();
//		insuranceObj.setFarmerId(14);
		
		insuranceRepo.insertInsurnceRecord(insuranceObj);
	}

	@Test
	public void InsuranceRecord() {

		Insurance insuranceObj = null;
		insuranceObj = insuranceRepo.find(Insurance.class, 24);
//		insuranceObj.setFarmerId(501);
		insuranceRepo.merge(insuranceObj);

	}

	@Test
	public void deleteInsuranceRecord() {
		Insurance insuranceObj = new Insurance();
		insuranceRepo.deleteInsuranceRecord(28);
	}

	@Test
	public void fetchInsuranceRecordById() {
		Insurance insuranceObj;
		insuranceObj = insuranceRepo.fetchInsuranceRecordById(24);
		System.out.println("-----------------------------------------");
		System.out.println("Insurance policyNum is " + insuranceObj.getPolicyNumber());
//		System.out.println("Insurance FarmerId is " + insuranceObj.getFarmerId());
		System.out.println("-----------------------------------------");

	}

	@Test
	public void fetchAllInsuranceRecords() {
		List<Insurance> insuranceList;
		insuranceList = insuranceRepo.fetchAllInsuranceRecords();
		for (Insurance insuranceObj : insuranceList) {
			System.out.println("-----------------------------------------");
			System.out.println("Insurance policyNum is " + insuranceObj.getPolicyNumber());
//			System.out.println("Insurance FarmerId is " + insuranceObj.getFarmerId());

			System.out.println("-----------------------------------------");
		}
	}
	
}