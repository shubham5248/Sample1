package com.farmerproject.demo;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Bidder;
import com.farmerproject.demo.entity.Bids_Made;
import com.farmerproject.demo.repository.BidderRepoImpl;
import com.farmerproject.demo.repository.Bids_MadeRepoImpl;


@SpringBootTest
public class ManyToOneTestCase {
	@Autowired
	Bids_MadeRepoImpl bidsRepoImpl;
	@Autowired
	BidderRepoImpl bidderRepoImpl;
	
	
	@Test
	void insertBids_Made() {
		Bids_Made bids=new Bids_Made();
		Bidder bidder=bidderRepoImpl.selectBidder(46);
		
		bids.setB_amount(5000);
		bids.setB_date(LocalDate.of(2021, 02, 02));
		bids.setBidder(bidder);
		
		bidsRepoImpl.bidsMadeInsert(bids);
		
	}
}
