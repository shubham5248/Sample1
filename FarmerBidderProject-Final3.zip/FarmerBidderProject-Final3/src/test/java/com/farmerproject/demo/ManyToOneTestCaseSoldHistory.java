package com.farmerproject.demo;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Bidder;
import com.farmerproject.demo.entity.SoldHistory;
import com.farmerproject.demo.repository.BidderRepoImpl;
import com.farmerproject.demo.repository.SoldHistoryImpl;



@SpringBootTest
public class ManyToOneTestCaseSoldHistory {
	@Autowired
	SoldHistoryImpl soldHistoryImpl;
	@Autowired
	BidderRepoImpl bidderRepoImpl;
	
	@Test
	void insertSoldHistory() {
	    SoldHistory soldHistory= new SoldHistory();
	    Bidder bidder=bidderRepoImpl.selectBidder(46);
	    soldHistory.setS_date(LocalDate.of(21,12, 10));
	    soldHistory.setS_cropName("Wheat");
	    soldHistory.setS_qty("65kg");
	    soldHistory.setS_msp("456");
	    soldHistory.setS_soldPrice(123);
	    soldHistory.setS_totalPrice(123);
	    soldHistory.setBidder(bidder);
	    
	    soldHistoryImpl.insertSoldHistory(soldHistory);
	    
	}
	

}
