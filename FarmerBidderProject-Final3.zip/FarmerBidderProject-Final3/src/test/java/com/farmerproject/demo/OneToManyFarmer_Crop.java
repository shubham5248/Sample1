package com.farmerproject.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Crop;
import com.farmerproject.demo.entity.Farmer;
import com.farmerproject.demo.repository.CropIMPL;
import com.farmerproject.demo.repository.FarmerIMPL;

@SpringBootTest
public class OneToManyFarmer_Crop {
	
	@Autowired
	FarmerIMPL farmerRepo;
	
	@Autowired
	CropIMPL cropRepo;
	
	@Test
	void insertOneFarmerToCrop() {
//		Farmer farmerObj=farmerRepo.fetchFarmerDetailsById(11);
		
		Crop cropObj=new Crop();
//		cropObj.setCropId(11);
		cropObj.setCropBasePrice(55555.4);
		cropObj.setCropMsp(77.78);
		cropObj.setCropPremium(999.69);
		cropObj.setCropType("kharip");
		cropObj.setCurrentPrice(9796.33);
//		cropObj.setFarmerObj2(farmerObj);
		cropRepo.insertCropDetails(cropObj);
		
//		Crop cropObj2=new Crop();
//		cropObj2.setCropId(12);
//		cropObj2.setCropBasePrice(55555.4);
//		cropObj2.setCropMsp(77.78);
//		cropObj2.setCropPremium(999.69);
//		cropObj2.setCropType("kharip");
//		cropObj2.setCurrentPrice(9796.33);
//		cropObj2.setFarmerObj2(farmerObj);
//		
//		cropRepo.insertCropDetails(cropObj2);
	}

}
