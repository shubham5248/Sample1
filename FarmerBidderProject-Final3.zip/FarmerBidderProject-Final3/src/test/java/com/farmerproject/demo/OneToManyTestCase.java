package com.farmerproject.demo;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Bidder;
import com.farmerproject.demo.entity.Bids_Made;
import com.farmerproject.demo.repository.BidderRepoImpl;
import com.farmerproject.demo.repository.Bids_MadeRepoImpl;


@SpringBootTest
public class OneToManyTestCase {

	@Autowired
	BidderRepoImpl repoImpl;
	

	@Autowired
	Bids_MadeRepoImpl bidsRepo;
	


	@Test
	void insertBidder() {
		Bidder bidder= repoImpl.selectBidder(46);
		
		Bids_Made bidsObj1=bidsRepo.selectBids_Made(48);
		Bids_Made bidsObj2=bidsRepo.selectBids_Made(49);
		Bids_Made bidsObj3=bidsRepo.selectBids_Made(50);
		
		bidsObj1.setBidder(bidder);
		bidsObj2.setBidder(bidder);
		bidsObj3.setBidder(bidder);
		
		
		Set<Bids_Made> bidsList=bidder.getBids_made();
		bidsList.add(bidsObj1);
		bidsList.add(bidsObj2);
		bidsList.add(bidsObj3);
		
		repoImpl.updateBidder(bidder);
		
//		
//		bidder.setB_name("Shubham");
//		bidder.setB_email("rushi051@gmail.com");
//		bidder.setB_contact_no(9888682987l);
//		bidder.setB_address("Pawna Nagar");
//		bidder.setB_trader_license("RUS12345");
//		bidder.setB_pincode(411033);
//		bidder.setB_city("Pune");
//		bidder.setB_state("Maharashtra");
//		bidder.setB_adharcard(123432178945l);
//		bidder.setB_account_number(654254987l);
//		bidder.setB_ifsc("FISC132521");
//		bidder.setB_bank_name("ICICI Bank");
		
		
	}
}
