package com.farmerproject.demo;

import java.util.LinkedList;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Bidder;
import com.farmerproject.demo.entity.SoldHistory;
import com.farmerproject.demo.repository.BidderRepoImpl;
import com.farmerproject.demo.repository.SoldHistoryImpl;



@SpringBootTest
public class OneToManyTestCaseSoldhistory {
	@Autowired
	BidderRepoImpl bidderRepoImpl;
	
	@Autowired
	SoldHistoryImpl soldHistoryImpl;

	@Test
	void insertBidder() {
		Bidder bidder= bidderRepoImpl.selectBidder(46);
		
		SoldHistory soldHistory1 = soldHistoryImpl.selectSoldHistory(26);
		SoldHistory soldHistory2 = soldHistoryImpl.selectSoldHistory(27);
		SoldHistory soldHistory3= soldHistoryImpl.selectSoldHistory(44);
		
		soldHistory1.setBidder(bidder);
		soldHistory2.setBidder(bidder);
		soldHistory3.setBidder(bidder);
		
		Set<SoldHistory> soldList=bidder.getSoldHistories();
		soldList.add(soldHistory1);
		soldList.add(soldHistory2);
		soldList.add(soldHistory3);
		
		bidderRepoImpl.updateBidder(bidder);
		
	}
	
}
