package com.farmerproject.demo;



import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Farmer;
import com.farmerproject.demo.entity.Insurance;
import com.farmerproject.demo.repository.FarmerIMPL;
import com.farmerproject.demo.repository.InsuranceIMPL;

@SpringBootTest
public class OneToManyTestInsurance_Farmer {
	
	@Autowired
	FarmerIMPL farmerRepo;
	
	@Autowired
	InsuranceIMPL insuranceRepo;
	
	@Test
	void insertInsuranceTest() {
		
		Farmer farmerObj=farmerRepo.fetchFarmerDetailsById(82);
		
		Insurance insuranceObj = new Insurance();
		insuranceObj.setFarmerObj(farmerObj);
		insuranceRepo.insertInsurnceRecord(insuranceObj);
				
	}

}