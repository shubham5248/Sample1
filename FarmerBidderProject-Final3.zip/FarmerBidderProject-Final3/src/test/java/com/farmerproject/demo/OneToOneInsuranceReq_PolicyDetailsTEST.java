package com.farmerproject.demo;


import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.InsuranceRequest;
import com.farmerproject.demo.entity.PolicyDetails;
import com.farmerproject.demo.repository.InsuranceRequestImpl;
import com.farmerproject.demo.repository.PolicyDetailsIMPL;

@SpringBootTest
public class OneToOneInsuranceReq_PolicyDetailsTEST {

	@Autowired
	InsuranceRequestImpl insuranceReqRepo1;

	@Autowired
	PolicyDetailsIMPL policyDetailsRepo;

	@Test
	void assignExistingInsurenceRequestToExistingPolicyDEtails() {

		InsuranceRequest insuranceReqObj = insuranceReqRepo1.find(InsuranceRequest.class, 109);

		PolicyDetails policyDetailsObj = policyDetailsRepo.find(PolicyDetails.class, 139);

		insuranceReqObj.setPolicyDetailsObj(policyDetailsObj);// are we setting the FK?
		policyDetailsObj.setInsReqPojo(insuranceReqObj);

		insuranceReqRepo1.merge(insuranceReqObj);
		policyDetailsRepo.merge(policyDetailsObj);

	}

	@Test
	public void insertNewInsuranceReqForExistingPolicy() {
		LocalDate localDate = LocalDate.of(2000, 1, 12);

		InsuranceRequest insuranceRequestObj = new InsuranceRequest();
		insuranceRequestObj.setiFid(102);
		insuranceRequestObj.setIseason("Kharip");
		insuranceRequestObj.setIld(localDate);
		insuranceRequestObj.setiCrop("Jwar");
		insuranceRequestObj.setiSumInsured(12560f);
		insuranceRequestObj.setiCompany("C Company");
		insuranceRequestObj.setiNomineeName("Julia");
		insuranceRequestObj.setiLandArea("West");
		insuranceRequestObj.setiPreAmount(55555f);

		PolicyDetails policyDetailsObj = policyDetailsRepo.find(PolicyDetails.class, 1);

		// Passport passport = entityManager.find(Passport.class, 67);

		insuranceRequestObj.setPolicyDetailsObj(policyDetailsObj);

		policyDetailsObj.setInsReqPojo(insuranceRequestObj);

		insuranceReqRepo1.persist(insuranceRequestObj);
		policyDetailsRepo.persist(policyDetailsObj);
	}

}