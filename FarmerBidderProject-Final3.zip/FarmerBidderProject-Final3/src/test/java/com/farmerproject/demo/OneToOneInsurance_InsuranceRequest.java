package com.farmerproject.demo;



import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Insurance;
import com.farmerproject.demo.entity.InsuranceRequest;
import com.farmerproject.demo.repository.InsuranceIMPL;
import com.farmerproject.demo.repository.InsuranceRequestImpl;

@SpringBootTest
public class OneToOneInsurance_InsuranceRequest {

	@Autowired
	InsuranceIMPL insuranceRepo;

	@Autowired
	InsuranceRequestImpl insuranceRequestRepo;

	@Test
	void assignInsuranceRecordToExistingInsuranceRequest() {

		Insurance insuranceObj = insuranceRepo.find(Insurance.class, 25);

		InsuranceRequest insuranceRequestObj = insuranceRequestRepo.find(InsuranceRequest.class, 8);

		insuranceObj.setInsuranceRequestObject(insuranceRequestObj);// are we setting the FK?
		insuranceRequestObj.setInsuranceObj(insuranceObj);

		insuranceRepo.merge(insuranceObj);
		insuranceRequestRepo.merge(insuranceRequestObj);
	}

	@Test
	public void insertInsuranceRecordForExistingPolicy() {

		Insurance insuranceObj = new Insurance();
		//insuranceObj.setFarmerId(601);

		InsuranceRequest insuranceReqestObj = insuranceRequestRepo.find(InsuranceRequest.class, 9);

		insuranceObj.setInsuranceRequestObject(insuranceReqestObj);

		insuranceReqestObj.setInsuranceObj(insuranceObj);

		insuranceRepo.persist(insuranceObj);
		insuranceRequestRepo.persist(insuranceReqestObj);
	}

}