package com.farmerproject.demo;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Crop;
import com.farmerproject.demo.entity.RequestBid;
import com.farmerproject.demo.repository.CropIMPL;
import com.farmerproject.demo.repository.RequestBidIMPL;

@SpringBootTest
public class OneToOneMappingRequestBid_Crop {
	
	
	@Autowired
	RequestBidIMPL reqBidRepo;

	@Autowired
	CropIMPL cropRepo;

	@Test
	void assignToExistingPolicyDEtails() {

		RequestBid reqBidObj = reqBidRepo.find(RequestBid.class, 41);

		Crop cropObj = cropRepo.find(Crop.class, 50);

		reqBidObj.setCropObj(cropObj);
		cropObj.setReqObj(reqBidObj);

		reqBidRepo.merge(reqBidObj);
		cropRepo.merge(cropObj);

	}

	@Test
	public void insertCropRequestForExistingPolicy() {
		

		RequestBid requestBidObj = new RequestBid();
		requestBidObj.setCropName("Rice");
		requestBidObj.setQuantityOfCrop(50.2);
		requestBidObj.setPhOfSoil(7.2);
		requestBidObj.setFertilizerType("Organic");

		Crop cropObj = cropRepo.find(Crop.class, 52);

		// Passport passport = entityManager.find(Passport.class, 67);

		requestBidObj.setCropObj(cropObj);

		cropObj.setReqObj(requestBidObj);

		reqBidRepo.persist(requestBidObj);
		cropRepo.persist(cropObj);
	}

}
