package com.farmerproject.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Crop;
import com.farmerproject.demo.entity.RequestBid;
import com.farmerproject.demo.repository.CropIMPL;
import com.farmerproject.demo.repository.RequestBidIMPL;

@SpringBootTest
public class OneToOne_RequestBid_Crop {

	@Autowired
	RequestBidIMPL requectBidRepo;

	@Autowired
	CropIMPL cropRepo;

	@Test
	void assignExisingCropRecordsToRequestBid() {

		RequestBid requestBidObj = requectBidRepo.find(RequestBid.class, 42);

		Crop cropObj = cropRepo.find(Crop.class, 47);

		cropObj.setReqObj(requestBidObj);
		requestBidObj.setCropObj(cropObj);

		requectBidRepo.merge(requestBidObj);
		cropRepo.merge(cropObj);
	}

	@Test
	public void insertNewInsuranceReqForExistingPolicy() {

		RequestBid requestBidObj = new RequestBid();

		requestBidObj.setCropName("Rice");
		requestBidObj.setQuantityOfCrop(50.2);
		requestBidObj.setPhOfSoil(7.2);
		requestBidObj.setFertilizerType("Organic");

		Crop cropObj = cropRepo.find(Crop.class, 52);

		requestBidObj.setCropObj(cropObj);
		cropObj.setReqObj(requestBidObj);

		requectBidRepo.persist(requestBidObj);
		cropRepo.persist(cropObj);

	}

}
