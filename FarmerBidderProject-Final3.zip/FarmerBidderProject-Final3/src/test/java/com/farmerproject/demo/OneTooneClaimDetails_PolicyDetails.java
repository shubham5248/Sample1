package com.farmerproject.demo;


import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.Claim;
import com.farmerproject.demo.entity.PolicyDetails;
import com.farmerproject.demo.repository.ClaimIMPL;
import com.farmerproject.demo.repository.PolicyDetailsIMPL;

@SpringBootTest
public class OneTooneClaimDetails_PolicyDetails {

	@Autowired
	PolicyDetailsIMPL policyDetailRepo;

	@Autowired
	ClaimIMPL claimRepo;

	@Test
	void assignExistingClaimDetailsToExistingPolicyDetails() {
		Claim claimObj = claimRepo.find(Claim.class, 15);

		PolicyDetails policyDetailsObj = policyDetailRepo.find(PolicyDetails.class, 1);

		claimObj.setPolicyDetailsObj(policyDetailsObj);// are we setting the FK?
		policyDetailsObj.setClaimObj(claimObj);

		claimRepo.merge(claimObj);
		claimRepo.merge(policyDetailsObj);
	}

	@Test
	public void insertNewClaimDetailsForExistingPolicy() {
		LocalDate localdateObj = LocalDate.of(2019, 5, 1);

		Claim claimObj = new Claim();
		claimObj.setReason("XYZ");
		claimObj.setDateOfClaim(localdateObj);

		PolicyDetails policyDetailsObj = policyDetailRepo.find(PolicyDetails.class, 5);

		// Passport passport = entityManager.find(Passport.class, 67);

		claimObj.setPolicyDetailsObj(policyDetailsObj);

		policyDetailsObj.setClaimObj(claimObj);

		claimRepo.persist(claimObj);
		policyDetailRepo.persist(policyDetailsObj);
	}

}