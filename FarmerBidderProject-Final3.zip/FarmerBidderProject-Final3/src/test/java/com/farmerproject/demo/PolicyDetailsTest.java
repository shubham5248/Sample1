package com.farmerproject.demo;


import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.farmerproject.demo.entity.PolicyDetails;
import com.farmerproject.demo.repository.PolicyDetailsIMPL;

@SpringBootTest
public class PolicyDetailsTest {

	@Autowired
	PolicyDetailsIMPL policyDetailsRepo1;

	@Test
	public void insertPolicy() {

		LocalDate ld = LocalDate.now();

		PolicyDetails policyDetails = new PolicyDetails();
		// policyDetails.setPdPolicyNum();
		policyDetails.setPdCompany("ABC com");
		policyDetails.setPdSum(9990.7F);
		policyDetails.setPdld(ld);
		policyDetails.setPdRequestNo(102);

		policyDetailsRepo1.insertPolicyDetails(policyDetails);
	}

	@Test
	public void updatePolicyDetails() {
		LocalDate lds = LocalDate.of(1998, 9, 8);
		PolicyDetails policyDetailsObj = null;
		policyDetailsObj = policyDetailsRepo1.find(PolicyDetails.class, 113);
		policyDetailsObj.setPdCompany("XYZ com");
		policyDetailsObj.setPdSum(9990.7F);
		policyDetailsObj.setPdld(lds);
		policyDetailsObj.setPdRequestNo(102);
		policyDetailsRepo1.updatePolicyDetail(policyDetailsObj);

	}

	@Test
	public void deletePolicydetail() {
		PolicyDetails policyDetailsObj = new PolicyDetails();
		policyDetailsRepo1.deletePolicyDetail(115);
	}

	@Test
	public void fetchPolicyDetailsById() {
		PolicyDetails policyDetailsObj;
		policyDetailsObj = policyDetailsRepo1.selectPolicyDetails(113);

		System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdPolicyNum());
		System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdRequestNo());
		System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdCompany());
		System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdSum());
		System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdld());
		System.out.println("-----------------------------------------");

	}

	@Test
	public void fetchAllPolicyDetails() {
		List<PolicyDetails> policyDetailsList;
		policyDetailsList = policyDetailsRepo1.selectPolicyDetails();
		for (PolicyDetails policyDetailsObj : policyDetailsList) {
			System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdPolicyNum());
			System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdRequestNo());
			System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdCompany());
			System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdSum());
			System.out.println("Policy Detail Id No is :" + policyDetailsObj.getPdld());
			System.out.println("-----------------------------------------");
		}
	}

}