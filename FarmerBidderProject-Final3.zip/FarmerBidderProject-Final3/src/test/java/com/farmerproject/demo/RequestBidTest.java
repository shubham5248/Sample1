package com.farmerproject.demo;

import org.springframework.boot.test.context.SpringBootTest;





import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.farmerproject.demo.entity.RequestBid;
import com.farmerproject.demo.repository.RequestBidIMPL;

@SpringBootTest
public class RequestBidTest {
	
	@Autowired
	RequestBidIMPL requestRepo;
	
	@Test
	void insertRequestBid() {
		RequestBid requestBidObj=new RequestBid();
		requestBidObj.setCropName("Rice");
		requestBidObj.setQuantityOfCrop(50.2);
		requestBidObj.setPhOfSoil(7.2);
		requestBidObj.setFertilizerType("Organic");
		requestRepo.insertRequestBid(requestBidObj);
	}
	@Test
	public void updateRequestBid() {
		
		RequestBid requestBidObj = null;
		requestBidObj = requestRepo.find(RequestBid.class, 42);
		requestBidObj.setCropName("wheat");
		requestBidObj.setQuantityOfCrop(55.2);
		requestBidObj.setPhOfSoil(9.2);
		requestBidObj.setFertilizerType("In-Organic");
		requestRepo.merge(requestBidObj);
	}
	@Test
	public void deleteRequestBidRecord() {
		RequestBid requestBidObj=new RequestBid();
		requestRepo.deleteRequestBidRecord(43);
	}
	@Test
	public void fetchRequestBidRecordById() {
		RequestBid requestBidObj;
		requestBidObj = requestRepo.fetchRequestBidById(89);
		System.out.println("-----------------------------------------");
		System.out.println("RequestBidRecord bidRequestNo is :" + requestBidObj.getBidRequestNo());
		System.out.println("RequestBidRecord Crop name is  : " + requestBidObj.getCropName());
		System.out.println("RequestBidRecord Crop Quantity is : " + requestBidObj.getQuantityOfCrop());
		System.out.println("RequestBidRecord PH of soil is :" + requestBidObj.getPhOfSoil());
		System.out.println("RequestBidRecord fertilizerType  is :" + requestBidObj.getFertilizerType());

		System.out.println("-----------------------------------------");

	}
	@Test
	public void fetchAllRequestBidRecords() {
		List<RequestBid> requestBidList;
		requestBidList = requestRepo.fetchAllRequestBidRecord();
		for (RequestBid requestBidObj : requestBidList) {
			System.out.println("-----------------------------------------");
			System.out.println("RequestBidRecord bidRequestNo is :" + requestBidObj.getBidRequestNo());
			System.out.println("RequestBidRecord Crop name is  : " + requestBidObj.getCropName());
			System.out.println("RequestBidRecord Crop Quantity is : " + requestBidObj.getQuantityOfCrop());
			System.out.println("RequestBidRecord PH of soil is :" + requestBidObj.getPhOfSoil());
			System.out.println("RequestBidRecord fertilizerType  is :" + requestBidObj.getFertilizerType());

			System.out.println("-----------------------------------------");
		}
	
	
	

}
}


























