import logo from './logo.svg';
import './App.css';

import FrontPage from './FrontPage';
import Farmer from './Farmer';
function App() {
  return (
    <div className="App">

      <FrontPage/>
    </div>
  );
}

export default App;
