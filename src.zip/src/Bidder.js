export default () => {
  return (
    <>
      <h1 class="login-heading-1">Bidder Registration Login Portal</h1><br/><br/>
      <div class=" container border border-3 col-6" >
        <div class="col-6 container" id="farmer-login-form">
          <div class="">
            <form>
              <div class="mb-3">
                <label for="exampleInputText1" class="form-label">
                  Bidder Username
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="exampleInputText1"
                  aria-describedby="textHelp"
                />
              </div>
              <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">
                  Password
                </label>
                <input
                  type="password"
                  class="form-control"
                  id="exampleInputPassword1"
                />
              </div>

              <button type="submit" class="btn btn-primary">
                Submit
              </button>
              <br />
              <br />
              <br />
              <br />

              <h5 class="new-registration">New User Register Here?</h5>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};
