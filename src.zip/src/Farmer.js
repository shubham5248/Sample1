import { Component } from "react";
import{connect} from "react-redux"

class Framer extends Component {
  state = {
    userName: "",

    password: "",
  };

  onValueChangeHandler = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });
  };

  onFormSubmitHandler = (event) => {
    event.preventDefault();
    console.log(this.state);
    this.props.addUser(this.state);
  };

  render() {
    return (
      <>
        <h1 class="login-heading-1">Farmer Registration Login Portal</h1>
        <br />
        <br />
        <div class=" container border border-3 col-6">
          <div class="col-6 container" id="farmer-login-form">
            <div class="">
              <form onSubmit={ this.onFormSubmitHandler}>
                <div class="mb-3">
                  <label for="exampleInputText1" class="form-label">
                    Farmer Username
                  </label>
                  <input
                    type="text"
                    class="form-control"
                    id="exampleInputText1"
                    aria-describedby="textHelp"
                    // id="age"
                    // className="form-control"
                    name="userName"
                    value={this.state.userName}
                    onChange={this.onValueChangeHandler}
                  />
                </div>
                <div class="mb-3">
                  <label for="exampleInputPassword1" class="form-label">
                    Password
                  </label>
                  <input
                    type="password"
                    class="form-control"
                    id="exampleInputPassword1"
                    // id="name"
                    // className="form-control"
                    name="password"
                    value={this.state.password}
                    onChange={this.onValueChangeHandler}
                  />
                </div>

                <button type="submit" class="btn btn-primary">
                  Submit
                </button>
                <br />
                <br />
                <br />
                <br />

                <h5 class="new-registration">New User Register Here?</h5>
              </form>
            </div>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = (dispatch) => {
  return {
    addPerson: (payload) => dispatch({ type: "USER_ADD", payload: payload }),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Framer);
