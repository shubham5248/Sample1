import { Component } from "react";
import { Routes,Route } from "react-router";
import Bidder from "./Bidder";
import Farmer from "./Farmer";
import Home from "./Home";
import Navbar from "./Navbar";


class FrontPage extends Component{
  render() {
    return (
      <>
   
        <br />
        <div class="shadow-lg p-3 mb-5 bg-body rounded">
          <p class="fs-1">Welcome to Farmer and Bidder  Portal</p>
          <p class="fs-3">Manage your profile with HIGH RETURNS</p>
        </div>
        <Navbar />
        <Routes>
          <Route path={"/Home"} element={<Home />} />
          <Route path={"/Farmer"} element={<Farmer />} />
          <Route path={"/Bidder"} element={<Bidder />} />
        </Routes>
      </>
    );
  }
};
export default FrontPage;

