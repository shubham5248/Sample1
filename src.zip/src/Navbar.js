import { Link} from "react-router-dom";

export default () => {
    return (
        <>
    <ul class="nav justify-content-end">
  <li class="nav-item">
    <Link class="nav-link active" aria-current="page" to="/Home">Home</Link>
  </li>
  <li class="nav-item">
    <Link class="nav-link" to="/Farmer">Farmer</Link>
  </li>
  <li class="nav-item">
    <Link class="nav-link" to="/Bidder">Bidder</Link>
  </li>
  <li class="nav-item">
    <Link class="nav-link disabled" to="#" tabindex="-1" aria-disabled="true">Disabled</Link>
  </li>
</ul>
 
            </>
    )
}