import {createStore}from "redux";


const initialState={
  farmerList:[],
  courseList:[]
}
const reducer= (state=initialState,action)=>{
    const{type,payload}=action;
       
    const farmerListCopy=[...state.farmerList];
    const courseListCopy=[...state.courseList];
    switch (type) {
        
        case "PERSON_UPDATE":
            let objectToBeUpdatedIndex = farmerListCopy.findIndex((person) => person.id === payload.id);
            farmerListCopy[objectToBeUpdatedIndex] = {
                ...farmerListCopy[objectToBeUpdatedIndex], ...payload,
            }
            alert("Updated")
            return {
                ...state,
                farmerList: farmerListCopy,
            }

        case "PERSON_ADD":
            const id = payload.id ? payload.id : state.farmerList.length + 1;
            farmerListCopy.push({ ...payload, id });



       const newState={
           ...state,
           farmerList:farmerListCopy
       }
    //    console.log(payload);
    //    farmerListCopy.push(payload);
    
       return {
        ...state,
        farmerList:farmerListCopy
    };

       case "PERSON_DELETE":
      console.log(payload);
     farmerListCopy.splice(payload,1);
      alert("Deleted")
      return {
        ...state,
       farmerList:farmerListCopy
   };

   case "ADD_COURSE":
       courseListCopy.push(payload);
       return{
        ...state,
           courseList:courseListCopy
       };


       case "COURSE_DELETE":
        console.log(payload);
       courseListCopy.splice(payload,1);
        alert("Deleted")
        return {
            ...state,
         courseList:courseListCopy
     };





   default: return state;
    }

};


const store=createStore(reducer);
export default store;